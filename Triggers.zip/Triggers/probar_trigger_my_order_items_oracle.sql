SET SERVEROUTPUT ON;
ALTER SESSION DISABLE PARALLEL DML;

-- Run trigger_my_order_items_inventories_oracle.sql first.
-- This script tests the same operations requested for ORDER_ITEMS,
-- but against MY_ORDER_ITEMS as required by the assignment.

BEGIN
    DBMS_OUTPUT.PUT_LINE('Resetting MY_ORDER_ITEMS and MY_INVENTORIES for tests...');
END;
/

TRUNCATE TABLE my_order_items;
TRUNCATE TABLE my_inventories;

INSERT INTO my_inventories (product_id, warehouse_id, quantity_on_hand)
VALUES (301, 1, 20);

INSERT INTO my_inventories (product_id, warehouse_id, quantity_on_hand)
VALUES (301, 2, 50);

INSERT INTO my_inventories (product_id, warehouse_id, quantity_on_hand)
VALUES (301, 5, 12);

INSERT INTO my_inventories (product_id, warehouse_id, quantity_on_hand)
VALUES (302, 1, 4);

INSERT INTO my_inventories (product_id, warehouse_id, quantity_on_hand)
VALUES (302, 3, 8);

INSERT INTO my_inventories (product_id, warehouse_id, quantity_on_hand)
VALUES (302, 7, 25);

BEGIN
    DBMS_OUTPUT.PUT_LINE('TEST 1: INSERT INTO my_order_items');
END;
/

INSERT INTO my_order_items (order_id, line_item_id, product_id, quantity, unit_price)
VALUES (9101, 1, 301, 10, 1200);

BEGIN
    DBMS_OUTPUT.PUT_LINE('TEST 2: DELETE FROM my_order_items');
END;
/

DELETE FROM my_order_items
WHERE order_id = 9101
  AND line_item_id = 1;

BEGIN
    DBMS_OUTPUT.PUT_LINE('Setup for TEST 3 and TEST 4');
END;
/

INSERT INTO my_order_items (order_id, line_item_id, product_id, quantity, unit_price)
VALUES (9102, 1, 302, 3, 300);

BEGIN
    DBMS_OUTPUT.PUT_LINE('TEST 3: UPDATE my_order_items requesting more items');
END;
/

UPDATE my_order_items
SET quantity = 7
WHERE order_id = 9102
  AND line_item_id = 1;

BEGIN
    DBMS_OUTPUT.PUT_LINE('TEST 4: UPDATE my_order_items returning items');
END;
/

UPDATE my_order_items
SET quantity = 2
WHERE order_id = 9102
  AND line_item_id = 1;

BEGIN
    DBMS_OUTPUT.PUT_LINE('TEST 5: INSERT failure because no single warehouse has enough stock');
    BEGIN
        INSERT INTO my_order_items (order_id, line_item_id, product_id, quantity, unit_price)
        VALUES (9103, 1, 301, 60, 1200);

        DBMS_OUTPUT.PUT_LINE('Unexpected result: TEST 5 should have failed.');
    EXCEPTION
        WHEN OTHERS THEN
            DBMS_OUTPUT.PUT_LINE('Expected failure in TEST 5: ' || SQLERRM);
    END;
END;
/

BEGIN
    DBMS_OUTPUT.PUT_LINE('Setup for TEST 6');
END;
/

INSERT INTO my_order_items (order_id, line_item_id, product_id, quantity, unit_price)
VALUES (9104, 1, 301, 5, 1200);

BEGIN
    DBMS_OUTPUT.PUT_LINE('TEST 6: UPDATE requesting more items fails because no single warehouse has enough stock');
    BEGIN
        UPDATE my_order_items
        SET quantity = 65
        WHERE order_id = 9104
          AND line_item_id = 1;

        DBMS_OUTPUT.PUT_LINE('Unexpected result: TEST 6 should have failed.');
    EXCEPTION
        WHEN OTHERS THEN
            DBMS_OUTPUT.PUT_LINE('Expected failure in TEST 6: ' || SQLERRM);
    END;
END;
/

BEGIN
    DBMS_OUTPUT.PUT_LINE('Final state of MY_ORDER_ITEMS');
END;
/

SELECT order_id, line_item_id, product_id, quantity, unit_price
FROM my_order_items
ORDER BY order_id, line_item_id;

BEGIN
    DBMS_OUTPUT.PUT_LINE('Final state of MY_INVENTORIES');
END;
/

SELECT product_id, warehouse_id, quantity_on_hand
FROM my_inventories
ORDER BY product_id, warehouse_id;
