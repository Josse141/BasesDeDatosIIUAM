PROMPT ============================================================
PROMPT 05 - Pruebas funcionales y escenarios de error
PROMPT ============================================================

SET SERVEROUTPUT ON

PROMPT ---- Resumen de cantidad de registros por tabla
SELECT 'CONTINENTES' AS tabla, COUNT(*) AS cantidad FROM continentes
UNION ALL SELECT 'PAISES', COUNT(*) FROM paises
UNION ALL SELECT 'MONEDAS', COUNT(*) FROM monedas
UNION ALL SELECT 'ESPECIALIDADES', COUNT(*) FROM especialidades
UNION ALL SELECT 'SERVICIOS', COUNT(*) FROM servicios
UNION ALL SELECT 'TIPOS_HORARIO', COUNT(*) FROM tipos_horario
UNION ALL SELECT 'CODIGOS_HORARIO', COUNT(*) FROM codigos_horario
UNION ALL SELECT 'USUARIOS_SISTEMA', COUNT(*) FROM usuarios_sistema
UNION ALL SELECT 'PERSONAS', COUNT(*) FROM personas
UNION ALL SELECT 'CLIENTES', COUNT(*) FROM clientes
UNION ALL SELECT 'ESPECIALISTAS', COUNT(*) FROM especialistas
UNION ALL SELECT 'ESPECIALISTA_ESPECIALIDADES', COUNT(*) FROM especialista_especialidades
UNION ALL SELECT 'SUCURSALES', COUNT(*) FROM sucursales
UNION ALL SELECT 'HORARIOS_ATENCION', COUNT(*) FROM horarios_atencion
UNION ALL SELECT 'FERIADOS', COUNT(*) FROM feriados
UNION ALL SELECT 'DISPONIBILIDAD_ESPECIALISTAS', COUNT(*) FROM disponibilidad_especialistas
UNION ALL SELECT 'AUSENCIAS_ESPECIALISTAS', COUNT(*) FROM ausencias_especialistas
UNION ALL SELECT 'CODIGOS_CUPON', COUNT(*) FROM codigos_cupon
UNION ALL SELECT 'CITAS', COUNT(*) FROM citas
UNION ALL SELECT 'PRECIOS_SERVICIOS', COUNT(*) FROM precios_servicios
UNION ALL SELECT 'FACTURACION', COUNT(*) FROM facturacion
ORDER BY 1;

PROMPT ---- Vista 1: historial de citas de personas
SELECT
    id_cliente,
    nombre_cliente,
    nombre_titular_cuenta,
    id_cita,
    sucursal,
    TO_CHAR(fecha, 'YYYY-MM-DD') AS fecha,
    hora_inicial,
    nombre_especialista,
    asistio_cita
FROM vw_historial_citas_persona
ORDER BY id_cliente, id_cita;

PROMPT ---- Vista 2: citas por especialista
SELECT
    nombre_especialista,
    TO_CHAR(fecha, 'YYYY-MM-DD') AS fecha,
    hora_inicial,
    numero_cita,
    nombre_sucursal,
    NVL(nombre_paciente_asignado, 'DISPONIBLE') AS nombre_paciente_asignado
FROM vw_citas_por_especialista
ORDER BY nombre_especialista, fecha, hora_inicial;

PROMPT ---- Vista 3: citas por especialidad
SELECT
    nombre_especialidad,
    nombre_especialista,
    TO_CHAR(fecha, 'YYYY-MM-DD') AS fecha,
    hora_inicial,
    numero_cita,
    nombre_sucursal,
    NVL(nombre_paciente_asignado, 'DISPONIBLE') AS nombre_paciente_asignado
FROM vw_citas_por_especialidad
ORDER BY nombre_especialidad, fecha, hora_inicial;

PROMPT ---- Exito: precio vigente del especialista 1004 para pediatria
SELECT fn_obtener_precio_vigente(1004, 2, TIMESTAMP '2026-04-15 08:00:00') AS precio_vigente
FROM dual;

PROMPT ---- Exito: descuento del cupon SALUD015 sobre una consulta de CRC 35000
SELECT fn_calcular_descuento_cupon(1, 35000, TIMESTAMP '2026-04-15 08:00:00') AS descuento
FROM dual;

PROMPT ---- Exito: impuesto de un subtotal neto de CRC 29750
SELECT fn_calcular_impuesto(2, 29750) AS impuesto
FROM dual;

PROMPT ---- Exito: total esperado de la cita 10000 = 33617.50
SELECT fn_calcular_total_factura(10000) AS total_factura
FROM dual;

PROMPT ---- Caso borde: cupon inactivo o expirado devuelve descuento 0
SELECT fn_calcular_descuento_cupon(3, 28000, TIMESTAMP '2026-04-14 09:30:00') AS descuento_cupon_expirado
FROM dual;

PROMPT ---- Error esperado: precio no vigente para especialista inexistente
BEGIN
    DBMS_OUTPUT.PUT_LINE('Precio: ' || fn_obtener_precio_vigente(9999, 2, TIMESTAMP '2026-04-15 08:00:00'));
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('ERROR CONTROLADO: ' || SQLERRM);
END;
/

PROMPT ---- Error esperado: cupon inexistente
BEGIN
    DBMS_OUTPUT.PUT_LINE('Descuento: ' || fn_calcular_descuento_cupon(9999, 20000, TIMESTAMP '2026-04-15 08:00:00'));
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('ERROR CONTROLADO: ' || SQLERRM);
END;
/

PROMPT ---- Error esperado: servicio inexistente para impuesto
BEGIN
    DBMS_OUTPUT.PUT_LINE('Impuesto: ' || fn_calcular_impuesto(9999, 10000));
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('ERROR CONTROLADO: ' || SQLERRM);
END;
/

PROMPT ---- Error esperado: cita inexistente para total de factura
BEGIN
    DBMS_OUTPUT.PUT_LINE('Total: ' || fn_calcular_total_factura(99999));
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('ERROR CONTROLADO: ' || SQLERRM);
END;
/

