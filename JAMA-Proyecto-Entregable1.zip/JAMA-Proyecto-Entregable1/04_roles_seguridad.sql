PROMPT ============================================================
PROMPT 04 - Roles de seguridad
PROMPT ============================================================

SET SERVEROUTPUT ON

DECLARE
    e_role_exists EXCEPTION;
    PRAGMA EXCEPTION_INIT(e_role_exists, -1921);
BEGIN
    BEGIN
        EXECUTE IMMEDIATE 'CREATE ROLE rol_reserva_citas';
        DBMS_OUTPUT.PUT_LINE('Rol rol_reserva_citas creado.');
    EXCEPTION
        WHEN e_role_exists THEN
            DBMS_OUTPUT.PUT_LINE('Rol rol_reserva_citas ya existia; se reutilizara.');
    END;

    BEGIN
        EXECUTE IMMEDIATE 'CREATE ROLE rol_consulta_citas';
        DBMS_OUTPUT.PUT_LINE('Rol rol_consulta_citas creado.');
    EXCEPTION
        WHEN e_role_exists THEN
            DBMS_OUTPUT.PUT_LINE('Rol rol_consulta_citas ya existia; se reutilizara.');
    END;

    BEGIN
        EXECUTE IMMEDIATE 'CREATE ROLE rol_aprobador_precios_citas';
        DBMS_OUTPUT.PUT_LINE('Rol rol_aprobador_precios_citas creado.');
    EXCEPTION
        WHEN e_role_exists THEN
            DBMS_OUTPUT.PUT_LINE('Rol rol_aprobador_precios_citas ya existia; se reutilizara.');
    END;
END;
/

GRANT SELECT ON clientes TO rol_reserva_citas;
GRANT SELECT ON personas TO rol_reserva_citas;
GRANT SELECT ON especialistas TO rol_reserva_citas;
GRANT SELECT ON sucursales TO rol_reserva_citas;
GRANT SELECT ON codigos_cupon TO rol_reserva_citas;
GRANT SELECT ON codigos_horario TO rol_reserva_citas;
GRANT SELECT, UPDATE ON citas TO rol_reserva_citas;

GRANT SELECT ON vw_historial_citas_persona TO rol_consulta_citas;
GRANT SELECT ON vw_citas_por_especialista TO rol_consulta_citas;
GRANT SELECT ON vw_citas_por_especialidad TO rol_consulta_citas;
GRANT SELECT ON sucursales TO rol_consulta_citas;
GRANT SELECT ON especialidades TO rol_consulta_citas;
GRANT SELECT ON especialistas TO rol_consulta_citas;
GRANT SELECT ON personas TO rol_consulta_citas;

GRANT SELECT, INSERT, UPDATE ON precios_servicios TO rol_aprobador_precios_citas;
GRANT SELECT ON usuarios_sistema TO rol_aprobador_precios_citas;
GRANT SELECT ON monedas TO rol_aprobador_precios_citas;
GRANT SELECT ON servicios TO rol_aprobador_precios_citas;
GRANT EXECUTE ON fn_obtener_precio_vigente TO rol_aprobador_precios_citas;
GRANT EXECUTE ON fn_calcular_descuento_cupon TO rol_aprobador_precios_citas;
GRANT EXECUTE ON fn_calcular_impuesto TO rol_aprobador_precios_citas;
GRANT EXECUTE ON fn_calcular_total_factura TO rol_aprobador_precios_citas;

PROMPT Roles creados y permisos asignados correctamente.
