PROMPT ============================================================
PROMPT Entregable Semana 10 - Hospitales de America S.A.
PROMPT Curso BIS-21 - Bases de Datos II
PROMPT Ejecucion recomendada en SQL*Plus o SQL Developer
PROMPT ============================================================

@@01_creacion_esquema_y_datos.sql
@@02_vistas_semana10.sql
@@03_funciones_facturacion.sql
@@04_roles_seguridad.sql
@@05_pruebas_semana10.sql

