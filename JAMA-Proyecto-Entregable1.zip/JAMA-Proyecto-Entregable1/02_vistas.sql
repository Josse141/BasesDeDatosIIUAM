PROMPT ============================================================
PROMPT 02 - Vistas completas del sistema
PROMPT ============================================================

CREATE OR REPLACE VIEW vw_historial_citas_persona AS
SELECT
    cli.id_cliente AS id_cliente,
    per_cli.nombre || ' ' || per_cli.apellidos AS nombre_cliente,
    NVL(per_tit.nombre || ' ' || per_tit.apellidos, per_cli.nombre || ' ' || per_cli.apellidos) AS nombre_titular_cuenta,
    NVL(cli.id_cliente_titular, cli.id_cliente) AS id_cliente_titular,
    c.id_cita,
    suc.nombre AS sucursal,
    c.fecha_cita AS fecha,
    TO_CHAR(ch.hora_inicial, 'HH24:MI') AS hora_inicial,
    per_esp.nombre || ' ' || per_esp.apellidos AS nombre_especialista,
    c.pudo_asistir AS asistio_cita
FROM citas c
JOIN clientes cli
    ON cli.id_cliente = c.id_cliente
JOIN personas per_cli
    ON per_cli.id_persona = cli.id_cliente
LEFT JOIN clientes cli_tit
    ON cli_tit.id_cliente = cli.id_cliente_titular
LEFT JOIN personas per_tit
    ON per_tit.id_persona = cli_tit.id_cliente
JOIN sucursales suc
    ON suc.id_sucursal = c.id_sucursal
JOIN especialistas esp
    ON esp.id_especialista = c.id_especialista
JOIN personas per_esp
    ON per_esp.id_persona = esp.id_especialista
JOIN codigos_horario ch
    ON ch.id_tipo_horario = suc.id_tipo_horario
   AND ch.id_codigo_horario = c.id_codigo_horario;

CREATE OR REPLACE VIEW vw_citas_por_especialista AS
SELECT
    per_esp.nombre || ' ' || per_esp.apellidos AS nombre_especialista,
    c.fecha_cita AS fecha,
    TO_CHAR(ch.hora_inicial, 'HH24:MI') AS hora_inicial,
    c.id_cita AS numero_cita,
    suc.nombre AS nombre_sucursal,
    CASE
        WHEN c.id_cliente IS NULL THEN NULL
        ELSE per_cli.nombre || ' ' || per_cli.apellidos
    END AS nombre_paciente_asignado
FROM citas c
JOIN especialistas esp
    ON esp.id_especialista = c.id_especialista
JOIN personas per_esp
    ON per_esp.id_persona = esp.id_especialista
JOIN sucursales suc
    ON suc.id_sucursal = c.id_sucursal
JOIN codigos_horario ch
    ON ch.id_tipo_horario = suc.id_tipo_horario
   AND ch.id_codigo_horario = c.id_codigo_horario
LEFT JOIN clientes cli
    ON cli.id_cliente = c.id_cliente
LEFT JOIN personas per_cli
    ON per_cli.id_persona = cli.id_cliente;

CREATE OR REPLACE VIEW vw_citas_por_especialidad AS
SELECT
    espd.descripcion AS nombre_especialidad,
    per_esp.nombre || ' ' || per_esp.apellidos AS nombre_especialista,
    c.fecha_cita AS fecha,
    TO_CHAR(ch.hora_inicial, 'HH24:MI') AS hora_inicial,
    c.id_cita AS numero_cita,
    suc.nombre AS nombre_sucursal,
    CASE
        WHEN c.id_cliente IS NULL THEN NULL
        ELSE per_cli.nombre || ' ' || per_cli.apellidos
    END AS nombre_paciente_asignado
FROM citas c
JOIN servicios srv
    ON srv.id_servicio = c.id_servicio
JOIN especialidades espd
    ON espd.id_especialidad = srv.id_especialidad
JOIN especialistas esp
    ON esp.id_especialista = c.id_especialista
JOIN personas per_esp
    ON per_esp.id_persona = esp.id_especialista
JOIN sucursales suc
    ON suc.id_sucursal = c.id_sucursal
JOIN codigos_horario ch
    ON ch.id_tipo_horario = suc.id_tipo_horario
   AND ch.id_codigo_horario = c.id_codigo_horario
LEFT JOIN clientes cli
    ON cli.id_cliente = c.id_cliente
LEFT JOIN personas per_cli
    ON per_cli.id_persona = cli.id_cliente;

PROMPT Vistas creadas correctamente.

