PROMPT ============================================================
PROMPT 01 - Creacion de esquema y carga de datos
PROMPT ============================================================

SET DEFINE OFF

BEGIN EXECUTE IMMEDIATE 'DROP VIEW vw_citas_por_especialidad'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP VIEW vw_citas_por_especialista'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP VIEW vw_historial_citas_persona'; EXCEPTION WHEN OTHERS THEN NULL; END;
/

BEGIN EXECUTE IMMEDIATE 'DROP FUNCTION fn_calcular_total_factura'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP FUNCTION fn_calcular_impuesto'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP FUNCTION fn_calcular_descuento_cupon'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP FUNCTION fn_obtener_precio_vigente'; EXCEPTION WHEN OTHERS THEN NULL; END;
/

BEGIN EXECUTE IMMEDIATE 'DROP TABLE facturacion CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE precios_servicios CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE citas CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE codigos_cupon CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE ausencias_especialistas CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE disponibilidad_especialistas CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE feriados CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE horarios_atencion CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE sucursales CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE especialista_especialidades CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE especialistas CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE clientes CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE personas CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE usuarios_sistema CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE codigos_horario CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE tipos_horario CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE servicios CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE especialidades CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE monedas CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE paises CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE continentes CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/

BEGIN EXECUTE IMMEDIATE 'DROP SEQUENCE seq_usuarios'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP SEQUENCE seq_personas'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP SEQUENCE seq_sucursales'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP SEQUENCE seq_feriados'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP SEQUENCE seq_cupones'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP SEQUENCE seq_citas'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP SEQUENCE seq_precios'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP SEQUENCE seq_facturas'; EXCEPTION WHEN OTHERS THEN NULL; END;
/

CREATE SEQUENCE seq_usuarios START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE seq_personas START WITH 1000 INCREMENT BY 1;
CREATE SEQUENCE seq_sucursales START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE seq_feriados START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE seq_cupones START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE seq_citas START WITH 10000 INCREMENT BY 1;
CREATE SEQUENCE seq_precios START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE seq_facturas START WITH 1 INCREMENT BY 1;

CREATE TABLE continentes (
    id_continente NUMBER(4) CONSTRAINT pk_continentes PRIMARY KEY,
    descripcion   VARCHAR2(80) CONSTRAINT nn_continentes_descripcion NOT NULL,
    CONSTRAINT uq_continentes_descripcion UNIQUE (descripcion)
);

CREATE TABLE paises (
    id_pais         NUMBER(4) CONSTRAINT pk_paises PRIMARY KEY,
    id_continente   NUMBER(4) CONSTRAINT nn_paises_continente NOT NULL,
    descripcion     VARCHAR2(80) CONSTRAINT nn_paises_descripcion NOT NULL,
    CONSTRAINT fk_paises_continentes
        FOREIGN KEY (id_continente) REFERENCES continentes (id_continente),
    CONSTRAINT uq_paises_descripcion UNIQUE (descripcion)
);

CREATE TABLE monedas (
    id_moneda     NUMBER(4) CONSTRAINT pk_monedas PRIMARY KEY,
    descripcion   VARCHAR2(60) CONSTRAINT nn_monedas_descripcion NOT NULL,
    simbolo       VARCHAR2(5) CONSTRAINT nn_monedas_simbolo NOT NULL,
    CONSTRAINT uq_monedas_descripcion UNIQUE (descripcion),
    CONSTRAINT uq_monedas_simbolo UNIQUE (simbolo)
);

CREATE TABLE especialidades (
    id_especialidad NUMBER(4) CONSTRAINT pk_especialidades PRIMARY KEY,
    descripcion     VARCHAR2(100) CONSTRAINT nn_especialidades_descripcion NOT NULL,
    CONSTRAINT uq_especialidades_descripcion UNIQUE (descripcion)
);

CREATE TABLE servicios (
    id_servicio          NUMBER(4) CONSTRAINT pk_servicios PRIMARY KEY,
    id_especialidad      NUMBER(4) CONSTRAINT nn_servicios_especialidad NOT NULL,
    descripcion          VARCHAR2(100) CONSTRAINT nn_servicios_descripcion NOT NULL,
    porcentaje_impuesto  NUMBER(5,2) DEFAULT 13 CONSTRAINT nn_servicios_impuesto NOT NULL,
    CONSTRAINT fk_servicios_especialidades
        FOREIGN KEY (id_especialidad) REFERENCES especialidades (id_especialidad),
    CONSTRAINT uq_servicios_descripcion UNIQUE (descripcion),
    CONSTRAINT ck_servicios_impuesto CHECK (porcentaje_impuesto BETWEEN 0 AND 100)
);

CREATE TABLE tipos_horario (
    id_tipo_horario   NUMBER(2) CONSTRAINT pk_tipos_horario PRIMARY KEY,
    descripcion       VARCHAR2(60) CONSTRAINT nn_tipos_horario_descripcion NOT NULL,
    minutos_duracion  NUMBER(3) CONSTRAINT nn_tipos_horario_minutos NOT NULL,
    CONSTRAINT ck_tipos_horario_id CHECK (id_tipo_horario IN (1, 2, 3, 4)),
    CONSTRAINT ck_tipos_horario_minutos CHECK (minutos_duracion IN (10, 15, 20, 30)),
    CONSTRAINT uq_tipos_horario_minutos UNIQUE (minutos_duracion)
);

CREATE TABLE codigos_horario (
    id_tipo_horario  NUMBER(2) CONSTRAINT nn_codigos_horario_tipo NOT NULL,
    id_codigo_horario NUMBER(4) CONSTRAINT nn_codigos_horario_codigo NOT NULL,
    hora_inicial     DATE CONSTRAINT nn_codigos_horario_inicio NOT NULL,
    hora_final       DATE CONSTRAINT nn_codigos_horario_final NOT NULL,
    CONSTRAINT pk_codigos_horario PRIMARY KEY (id_tipo_horario, id_codigo_horario),
    CONSTRAINT fk_codigos_horario_tipo
        FOREIGN KEY (id_tipo_horario) REFERENCES tipos_horario (id_tipo_horario),
    CONSTRAINT ck_codigos_horario_rango CHECK (hora_final > hora_inicial)
);

CREATE TABLE usuarios_sistema (
    id_usuario       NUMBER DEFAULT seq_usuarios.NEXTVAL CONSTRAINT pk_usuarios_sistema PRIMARY KEY,
    nombre_usuario   VARCHAR2(40) CONSTRAINT nn_usuarios_nombre_usuario NOT NULL,
    nombre_completo  VARCHAR2(120) CONSTRAINT nn_usuarios_nombre_completo NOT NULL,
    rol_operativo    VARCHAR2(40) CONSTRAINT nn_usuarios_rol_operativo NOT NULL,
    CONSTRAINT uq_usuarios_nombre_usuario UNIQUE (nombre_usuario)
);

CREATE TABLE personas (
    id_persona             NUMBER DEFAULT seq_personas.NEXTVAL CONSTRAINT pk_personas PRIMARY KEY,
    documento_identidad    VARCHAR2(25) CONSTRAINT nn_personas_documento NOT NULL,
    id_pais                NUMBER(4) CONSTRAINT nn_personas_pais NOT NULL,
    nombre                 VARCHAR2(80) CONSTRAINT nn_personas_nombre NOT NULL,
    apellidos              VARCHAR2(120) CONSTRAINT nn_personas_apellidos NOT NULL,
    sexo                   CHAR(1) CONSTRAINT nn_personas_sexo NOT NULL,
    fecha_nacimiento       DATE CONSTRAINT nn_personas_fecha_nacimiento NOT NULL,
    telefono               VARCHAR2(20) CONSTRAINT nn_personas_telefono NOT NULL,
    CONSTRAINT fk_personas_paises
        FOREIGN KEY (id_pais) REFERENCES paises (id_pais),
    CONSTRAINT uq_personas_documento UNIQUE (documento_identidad),
    CONSTRAINT ck_personas_sexo CHECK (sexo IN ('F', 'M', 'X'))
);

CREATE TABLE clientes (
    id_cliente           NUMBER CONSTRAINT pk_clientes PRIMARY KEY,
    id_cliente_titular   NUMBER,
    estado               NUMBER(1) DEFAULT 1 CONSTRAINT nn_clientes_estado NOT NULL,
    CONSTRAINT fk_clientes_personas
        FOREIGN KEY (id_cliente) REFERENCES personas (id_persona),
    CONSTRAINT fk_clientes_titular
        FOREIGN KEY (id_cliente_titular) REFERENCES clientes (id_cliente),
    CONSTRAINT ck_clientes_estado CHECK (estado IN (0, 1))
);

CREATE TABLE especialistas (
    id_especialista   NUMBER CONSTRAINT pk_especialistas PRIMARY KEY,
    codigo_colegio    VARCHAR2(20) CONSTRAINT nn_especialistas_codigo_colegio NOT NULL,
    CONSTRAINT fk_especialistas_personas
        FOREIGN KEY (id_especialista) REFERENCES personas (id_persona),
    CONSTRAINT uq_especialistas_codigo_colegio UNIQUE (codigo_colegio)
);

CREATE TABLE especialista_especialidades (
    id_especialista  NUMBER CONSTRAINT nn_ee_especialista NOT NULL,
    id_especialidad  NUMBER CONSTRAINT nn_ee_especialidad NOT NULL,
    CONSTRAINT pk_especialista_especialidades PRIMARY KEY (id_especialista, id_especialidad),
    CONSTRAINT fk_ee_especialistas
        FOREIGN KEY (id_especialista) REFERENCES especialistas (id_especialista),
    CONSTRAINT fk_ee_especialidades
        FOREIGN KEY (id_especialidad) REFERENCES especialidades (id_especialidad)
);

CREATE TABLE sucursales (
    id_sucursal       NUMBER DEFAULT seq_sucursales.NEXTVAL CONSTRAINT pk_sucursales PRIMARY KEY,
    nombre            VARCHAR2(80) CONSTRAINT nn_sucursales_nombre NOT NULL,
    provincia         VARCHAR2(50) CONSTRAINT nn_sucursales_provincia NOT NULL,
    id_tipo_horario   NUMBER(2) CONSTRAINT nn_sucursales_tipo_horario NOT NULL,
    dias_laborales    NUMBER(3) CONSTRAINT nn_sucursales_dias_laborales NOT NULL,
    CONSTRAINT fk_sucursales_tipos_horario
        FOREIGN KEY (id_tipo_horario) REFERENCES tipos_horario (id_tipo_horario),
    CONSTRAINT uq_sucursales_nombre UNIQUE (nombre),
    CONSTRAINT ck_sucursales_dias_laborales CHECK (dias_laborales BETWEEN 0 AND 127)
);

CREATE TABLE horarios_atencion (
    id_sucursal      NUMBER CONSTRAINT nn_horarios_atencion_sucursal NOT NULL,
    id_especialista  NUMBER CONSTRAINT nn_horarios_atencion_especialista NOT NULL,
    dia_semana       NUMBER(1) CONSTRAINT nn_horarios_atencion_dia NOT NULL,
    hora_inicial     DATE CONSTRAINT nn_horarios_atencion_inicio NOT NULL,
    hora_final       DATE CONSTRAINT nn_horarios_atencion_final NOT NULL,
    CONSTRAINT pk_horarios_atencion
        PRIMARY KEY (id_sucursal, id_especialista, dia_semana, hora_inicial),
    CONSTRAINT fk_horarios_atencion_sucursales
        FOREIGN KEY (id_sucursal) REFERENCES sucursales (id_sucursal),
    CONSTRAINT fk_horarios_atencion_especialistas
        FOREIGN KEY (id_especialista) REFERENCES especialistas (id_especialista),
    CONSTRAINT ck_horarios_atencion_dia CHECK (dia_semana BETWEEN 0 AND 6),
    CONSTRAINT ck_horarios_atencion_rango CHECK (hora_final > hora_inicial)
);

CREATE TABLE feriados (
    id_feriado       NUMBER DEFAULT seq_feriados.NEXTVAL CONSTRAINT pk_feriados PRIMARY KEY,
    fecha_feriado    DATE CONSTRAINT nn_feriados_fecha NOT NULL,
    id_sucursal      NUMBER DEFAULT -1 CONSTRAINT nn_feriados_sucursal NOT NULL,
    descripcion      VARCHAR2(120) CONSTRAINT nn_feriados_descripcion NOT NULL,
    CONSTRAINT ck_feriados_sucursal CHECK (id_sucursal = -1 OR id_sucursal > 0)
);

CREATE TABLE disponibilidad_especialistas (
    id_sucursal      NUMBER CONSTRAINT nn_disponibilidad_sucursal NOT NULL,
    id_especialista  NUMBER CONSTRAINT nn_disponibilidad_especialista NOT NULL,
    dia_semana       NUMBER(1) CONSTRAINT nn_disponibilidad_dia NOT NULL,
    hora_inicio      DATE CONSTRAINT nn_disponibilidad_inicio NOT NULL,
    hora_final       DATE CONSTRAINT nn_disponibilidad_final NOT NULL,
    CONSTRAINT pk_disponibilidad_especialistas
        PRIMARY KEY (id_sucursal, id_especialista, dia_semana, hora_inicio),
    CONSTRAINT fk_disponibilidad_sucursales
        FOREIGN KEY (id_sucursal) REFERENCES sucursales (id_sucursal),
    CONSTRAINT fk_disponibilidad_especialistas
        FOREIGN KEY (id_especialista) REFERENCES especialistas (id_especialista),
    CONSTRAINT ck_disponibilidad_dia CHECK (dia_semana BETWEEN 0 AND 6),
    CONSTRAINT ck_disponibilidad_rango CHECK (hora_final > hora_inicio)
);

CREATE TABLE ausencias_especialistas (
    id_especialista  NUMBER CONSTRAINT nn_ausencias_especialista NOT NULL,
    fecha_inicio     DATE CONSTRAINT nn_ausencias_inicio NOT NULL,
    fecha_fin        DATE CONSTRAINT nn_ausencias_fin NOT NULL,
    motivo           VARCHAR2(120) CONSTRAINT nn_ausencias_motivo NOT NULL,
    CONSTRAINT pk_ausencias_especialistas PRIMARY KEY (id_especialista, fecha_inicio),
    CONSTRAINT fk_ausencias_especialistas
        FOREIGN KEY (id_especialista) REFERENCES especialistas (id_especialista),
    CONSTRAINT ck_ausencias_rango CHECK (fecha_fin >= fecha_inicio)
);

CREATE TABLE codigos_cupon (
    id_cupon                 NUMBER DEFAULT seq_cupones.NEXTVAL CONSTRAINT pk_codigos_cupon PRIMARY KEY,
    codigo                   VARCHAR2(8) CONSTRAINT nn_codigos_cupon_codigo NOT NULL,
    descripcion              VARCHAR2(120) CONSTRAINT nn_codigos_cupon_descripcion NOT NULL,
    fecha_hora_inicio        TIMESTAMP CONSTRAINT nn_codigos_cupon_inicio NOT NULL,
    fecha_hora_fin           TIMESTAMP CONSTRAINT nn_codigos_cupon_fin NOT NULL,
    maxima_cantidad_usos     NUMBER(5) CONSTRAINT nn_codigos_cupon_max_usos NOT NULL,
    usos_restantes           NUMBER(5) CONSTRAINT nn_codigos_cupon_restantes NOT NULL,
    tipo_descuento           VARCHAR2(20) CONSTRAINT nn_codigos_cupon_tipo NOT NULL,
    monto_descuento          NUMBER(10,2) DEFAULT 0 CONSTRAINT nn_codigos_cupon_monto_descuento NOT NULL,
    monto_minimo_factura     NUMBER(10,2) DEFAULT 0 CONSTRAINT nn_codigos_cupon_monto_minimo NOT NULL,
    esta_activo              NUMBER(1) DEFAULT 1 CONSTRAINT nn_codigos_cupon_activo NOT NULL,
    CONSTRAINT uq_codigos_cupon_codigo UNIQUE (codigo),
    CONSTRAINT ck_codigos_cupon_fechas CHECK (fecha_hora_fin > fecha_hora_inicio),
    CONSTRAINT ck_codigos_cupon_max_usos CHECK (maxima_cantidad_usos > 0),
    CONSTRAINT ck_codigos_cupon_restantes CHECK (usos_restantes BETWEEN 0 AND maxima_cantidad_usos),
    CONSTRAINT ck_codigos_cupon_tipo CHECK (
        tipo_descuento IN ('PORCENTAJE', 'MONTO_FIJO', 'CITA_GRATIS', 'BONO')
    ),
    CONSTRAINT ck_codigos_cupon_descuento CHECK (monto_descuento >= 0),
    CONSTRAINT ck_codigos_cupon_minimo CHECK (monto_minimo_factura >= 0),
    CONSTRAINT ck_codigos_cupon_activo CHECK (esta_activo IN (0, 1))
);

CREATE TABLE citas (
    id_cita            NUMBER DEFAULT seq_citas.NEXTVAL CONSTRAINT pk_citas PRIMARY KEY,
    id_cliente         NUMBER,
    id_sucursal        NUMBER CONSTRAINT nn_citas_sucursal NOT NULL,
    id_especialista    NUMBER CONSTRAINT nn_citas_especialista NOT NULL,
    id_codigo_horario  NUMBER CONSTRAINT nn_citas_codigo_horario NOT NULL,
    fecha_cita         DATE CONSTRAINT nn_citas_fecha NOT NULL,
    id_servicio        NUMBER CONSTRAINT nn_citas_servicio NOT NULL,
    id_cupon           NUMBER,
    pudo_asistir       NUMBER(1),
    CONSTRAINT fk_citas_clientes
        FOREIGN KEY (id_cliente) REFERENCES clientes (id_cliente),
    CONSTRAINT fk_citas_sucursales
        FOREIGN KEY (id_sucursal) REFERENCES sucursales (id_sucursal),
    CONSTRAINT fk_citas_especialistas
        FOREIGN KEY (id_especialista) REFERENCES especialistas (id_especialista),
    CONSTRAINT fk_citas_servicios
        FOREIGN KEY (id_servicio) REFERENCES servicios (id_servicio),
    CONSTRAINT fk_citas_cupones
        FOREIGN KEY (id_cupon) REFERENCES codigos_cupon (id_cupon),
    CONSTRAINT uq_citas_slot
        UNIQUE (id_sucursal, id_especialista, fecha_cita, id_codigo_horario),
    CONSTRAINT ck_citas_codigo_horario CHECK (id_codigo_horario > 0),
    CONSTRAINT ck_citas_asistencia CHECK (pudo_asistir IN (0, 1) OR pudo_asistir IS NULL)
);

CREATE TABLE precios_servicios (
    id_precio               NUMBER DEFAULT seq_precios.NEXTVAL CONSTRAINT pk_precios_servicios PRIMARY KEY,
    id_especialista         NUMBER CONSTRAINT nn_precios_especialista NOT NULL,
    id_servicio             NUMBER CONSTRAINT nn_precios_servicio NOT NULL,
    fecha_inicio_vigencia   TIMESTAMP CONSTRAINT nn_precios_inicio_vigencia NOT NULL,
    fecha_fin_vigencia      TIMESTAMP,
    estado                  NUMBER(1) DEFAULT 0 CONSTRAINT nn_precios_estado NOT NULL,
    id_moneda               NUMBER(4) CONSTRAINT nn_precios_moneda NOT NULL,
    precio                  NUMBER(10,2) CONSTRAINT nn_precios_precio NOT NULL,
    id_usuario_registro     NUMBER CONSTRAINT nn_precios_usuario_registro NOT NULL,
    fecha_hora_registro     TIMESTAMP DEFAULT SYSTIMESTAMP CONSTRAINT nn_precios_fecha_registro NOT NULL,
    id_usuario_aprobacion   NUMBER,
    fecha_hora_aprobacion   TIMESTAMP,
    CONSTRAINT fk_precios_especialistas
        FOREIGN KEY (id_especialista) REFERENCES especialistas (id_especialista),
    CONSTRAINT fk_precios_servicios
        FOREIGN KEY (id_servicio) REFERENCES servicios (id_servicio),
    CONSTRAINT fk_precios_monedas
        FOREIGN KEY (id_moneda) REFERENCES monedas (id_moneda),
    CONSTRAINT fk_precios_usuario_registro
        FOREIGN KEY (id_usuario_registro) REFERENCES usuarios_sistema (id_usuario),
    CONSTRAINT fk_precios_usuario_aprobacion
        FOREIGN KEY (id_usuario_aprobacion) REFERENCES usuarios_sistema (id_usuario),
    CONSTRAINT uq_precios_inicio UNIQUE (id_especialista, id_servicio, fecha_inicio_vigencia),
    CONSTRAINT ck_precios_estado CHECK (estado IN (0, 1, 2)),
    CONSTRAINT ck_precios_precio CHECK (precio > 0)
);

CREATE TABLE facturacion (
    id_factura               NUMBER DEFAULT seq_facturas.NEXTVAL CONSTRAINT pk_facturacion PRIMARY KEY,
    id_cita                  NUMBER CONSTRAINT nn_facturacion_cita NOT NULL,
    fecha_hora_facturacion   TIMESTAMP DEFAULT SYSTIMESTAMP CONSTRAINT nn_facturacion_fecha NOT NULL,
    monto_bruto              NUMBER(10,2) CONSTRAINT nn_facturacion_bruto NOT NULL,
    monto_descuento          NUMBER(10,2) CONSTRAINT nn_facturacion_descuento NOT NULL,
    monto_impuesto           NUMBER(10,2) CONSTRAINT nn_facturacion_impuesto NOT NULL,
    monto_total              NUMBER(10,2) CONSTRAINT nn_facturacion_total NOT NULL,
    CONSTRAINT fk_facturacion_citas
        FOREIGN KEY (id_cita) REFERENCES citas (id_cita),
    CONSTRAINT uq_facturacion_cita UNIQUE (id_cita),
    CONSTRAINT ck_facturacion_montos CHECK (
        monto_bruto >= 0
        AND monto_descuento >= 0
        AND monto_impuesto >= 0
        AND monto_total >= 0
    )
);

INSERT INTO continentes (id_continente, descripcion) VALUES (1, 'America');
INSERT INTO continentes (id_continente, descripcion) VALUES (2, 'Europa');

INSERT INTO paises (id_pais, id_continente, descripcion) VALUES (188, 1, 'Costa Rica');
INSERT INTO paises (id_pais, id_continente, descripcion) VALUES (840, 1, 'Estados Unidos');
INSERT INTO paises (id_pais, id_continente, descripcion) VALUES (724, 2, 'Espana');

INSERT INTO monedas (id_moneda, descripcion, simbolo) VALUES (1, 'Colon costarricense', 'CRC');
INSERT INTO monedas (id_moneda, descripcion, simbolo) VALUES (2, 'Dolar estadounidense', 'USD');

INSERT INTO especialidades (id_especialidad, descripcion) VALUES (1, 'Medicina General');
INSERT INTO especialidades (id_especialidad, descripcion) VALUES (2, 'Pediatria');
INSERT INTO especialidades (id_especialidad, descripcion) VALUES (3, 'Cardiologia');
INSERT INTO especialidades (id_especialidad, descripcion) VALUES (4, 'Alergologia');

INSERT INTO servicios (id_servicio, id_especialidad, descripcion, porcentaje_impuesto)
VALUES (1, 1, 'Consulta de medicina general', 13);
INSERT INTO servicios (id_servicio, id_especialidad, descripcion, porcentaje_impuesto)
VALUES (2, 2, 'Consulta pediatrica', 13);
INSERT INTO servicios (id_servicio, id_especialidad, descripcion, porcentaje_impuesto)
VALUES (3, 3, 'Consulta cardiologica', 13);
INSERT INTO servicios (id_servicio, id_especialidad, descripcion, porcentaje_impuesto)
VALUES (4, 4, 'Consulta alergologica', 13);

INSERT INTO tipos_horario (id_tipo_horario, descripcion, minutos_duracion)
VALUES (1, 'Citas cada 30 minutos', 30);
INSERT INTO tipos_horario (id_tipo_horario, descripcion, minutos_duracion)
VALUES (2, 'Citas cada 20 minutos', 20);
INSERT INTO tipos_horario (id_tipo_horario, descripcion, minutos_duracion)
VALUES (3, 'Citas cada 15 minutos', 15);
INSERT INTO tipos_horario (id_tipo_horario, descripcion, minutos_duracion)
VALUES (4, 'Citas cada 10 minutos', 10);

DECLARE
    v_total_bloques NUMBER;
BEGIN
    FOR r IN (
        SELECT id_tipo_horario, minutos_duracion
        FROM tipos_horario
        ORDER BY id_tipo_horario
    ) LOOP
        v_total_bloques := (24 * 60) / r.minutos_duracion;

        FOR i IN 1 .. v_total_bloques LOOP
            INSERT INTO codigos_horario (
                id_tipo_horario,
                id_codigo_horario,
                hora_inicial,
                hora_final
            ) VALUES (
                r.id_tipo_horario,
                i,
                TO_DATE('2000-01-01 00:00', 'YYYY-MM-DD HH24:MI')
                    + ((i - 1) * r.minutos_duracion) / (24 * 60),
                TO_DATE('2000-01-01 00:00', 'YYYY-MM-DD HH24:MI')
                    + (i * r.minutos_duracion) / (24 * 60)
            );
        END LOOP;
    END LOOP;
END;
/

INSERT INTO usuarios_sistema (id_usuario, nombre_usuario, nombre_completo, rol_operativo)
VALUES (1, 'analista.bd', 'Analista de Base de Datos', 'ANALISIS');
INSERT INTO usuarios_sistema (id_usuario, nombre_usuario, nombre_completo, rol_operativo)
VALUES (2, 'aprobador.precios', 'Supervisora de Precios', 'APROBACION_PRECIOS');
INSERT INTO usuarios_sistema (id_usuario, nombre_usuario, nombre_completo, rol_operativo)
VALUES (3, 'reserva.citas', 'Agente de Reservas', 'RESERVA_CITAS');

INSERT INTO personas (
    id_persona, documento_identidad, id_pais, nombre, apellidos, sexo, fecha_nacimiento, telefono
) VALUES (
    1001, '1-1111-1111', 188, 'Ana', 'Villegas Mora', 'F', DATE '1985-08-14', '8888-1001'
);
INSERT INTO personas (
    id_persona, documento_identidad, id_pais, nombre, apellidos, sexo, fecha_nacimiento, telefono
) VALUES (
    1002, '1-2222-2222', 188, 'Luis', 'Villegas Mora', 'M', DATE '2012-03-05', '8888-1002'
);
INSERT INTO personas (
    id_persona, documento_identidad, id_pais, nombre, apellidos, sexo, fecha_nacimiento, telefono
) VALUES (
    1003, '1-3333-3333', 188, 'Sofia', 'Villegas Mora', 'F', DATE '2015-07-22', '8888-1003'
);
INSERT INTO personas (
    id_persona, documento_identidad, id_pais, nombre, apellidos, sexo, fecha_nacimiento, telefono
) VALUES (
    1004, '1-4444-4444', 188, 'Carlos', 'Piedra Vega', 'M', DATE '1978-11-09', '8888-1004'
);
INSERT INTO personas (
    id_persona, documento_identidad, id_pais, nombre, apellidos, sexo, fecha_nacimiento, telefono
) VALUES (
    1005, '1-5555-5555', 188, 'Elena', 'Madrigal Soto', 'F', DATE '1980-04-20', '8888-1005'
);
INSERT INTO personas (
    id_persona, documento_identidad, id_pais, nombre, apellidos, sexo, fecha_nacimiento, telefono
) VALUES (
    1006, '1-6666-6666', 188, 'Laura', 'Carvajal Ruiz', 'F', DATE '1988-01-30', '8888-1006'
);
INSERT INTO personas (
    id_persona, documento_identidad, id_pais, nombre, apellidos, sexo, fecha_nacimiento, telefono
) VALUES (
    1007, 'P-778899', 840, 'Marco', 'Salas Brenes', 'M', DATE '1991-12-03', '8888-1007'
);

INSERT INTO clientes (id_cliente, id_cliente_titular, estado) VALUES (1001, NULL, 1);
INSERT INTO clientes (id_cliente, id_cliente_titular, estado) VALUES (1002, 1001, 1);
INSERT INTO clientes (id_cliente, id_cliente_titular, estado) VALUES (1003, 1001, 1);
INSERT INTO clientes (id_cliente, id_cliente_titular, estado) VALUES (1007, NULL, 1);

INSERT INTO especialistas (id_especialista, codigo_colegio) VALUES (1004, 'COL-2045');
INSERT INTO especialistas (id_especialista, codigo_colegio) VALUES (1005, 'COL-3188');
INSERT INTO especialistas (id_especialista, codigo_colegio) VALUES (1006, 'COL-4120');

INSERT INTO especialista_especialidades (id_especialista, id_especialidad) VALUES (1004, 2);
INSERT INTO especialista_especialidades (id_especialista, id_especialidad) VALUES (1004, 4);
INSERT INTO especialista_especialidades (id_especialista, id_especialidad) VALUES (1005, 3);
INSERT INTO especialista_especialidades (id_especialista, id_especialidad) VALUES (1006, 1);

INSERT INTO sucursales (id_sucursal, nombre, provincia, id_tipo_horario, dias_laborales)
VALUES (1, 'Liberia', 'Guanacaste', 2, 126);
INSERT INTO sucursales (id_sucursal, nombre, provincia, id_tipo_horario, dias_laborales)
VALUES (2, 'Cartago', 'Cartago', 1, 62);
INSERT INTO sucursales (id_sucursal, nombre, provincia, id_tipo_horario, dias_laborales)
VALUES (3, 'SJ-1', 'San Jose', 3, 126);

INSERT INTO horarios_atencion (id_sucursal, id_especialista, dia_semana, hora_inicial, hora_final)
VALUES (1, 1004, 1, TO_DATE('2000-01-01 08:00', 'YYYY-MM-DD HH24:MI'), TO_DATE('2000-01-01 12:00', 'YYYY-MM-DD HH24:MI'));
INSERT INTO horarios_atencion (id_sucursal, id_especialista, dia_semana, hora_inicial, hora_final)
VALUES (1, 1004, 3, TO_DATE('2000-01-01 08:00', 'YYYY-MM-DD HH24:MI'), TO_DATE('2000-01-01 12:00', 'YYYY-MM-DD HH24:MI'));
INSERT INTO horarios_atencion (id_sucursal, id_especialista, dia_semana, hora_inicial, hora_final)
VALUES (2, 1005, 2, TO_DATE('2000-01-01 10:00', 'YYYY-MM-DD HH24:MI'), TO_DATE('2000-01-01 15:00', 'YYYY-MM-DD HH24:MI'));
INSERT INTO horarios_atencion (id_sucursal, id_especialista, dia_semana, hora_inicial, hora_final)
VALUES (3, 1006, 2, TO_DATE('2000-01-01 09:00', 'YYYY-MM-DD HH24:MI'), TO_DATE('2000-01-01 17:00', 'YYYY-MM-DD HH24:MI'));
INSERT INTO horarios_atencion (id_sucursal, id_especialista, dia_semana, hora_inicial, hora_final)
VALUES (3, 1006, 4, TO_DATE('2000-01-01 09:00', 'YYYY-MM-DD HH24:MI'), TO_DATE('2000-01-01 17:00', 'YYYY-MM-DD HH24:MI'));

INSERT INTO feriados (id_feriado, fecha_feriado, id_sucursal, descripcion)
VALUES (1, DATE '2026-09-15', -1, 'Independencia de Costa Rica');
INSERT INTO feriados (id_feriado, fecha_feriado, id_sucursal, descripcion)
VALUES (2, DATE '2026-08-02', 2, 'Fiesta de la Virgen de los Angeles');

INSERT INTO disponibilidad_especialistas (id_sucursal, id_especialista, dia_semana, hora_inicio, hora_final)
VALUES (1, 1004, 1, TO_DATE('2000-01-01 08:00', 'YYYY-MM-DD HH24:MI'), TO_DATE('2000-01-01 12:00', 'YYYY-MM-DD HH24:MI'));
INSERT INTO disponibilidad_especialistas (id_sucursal, id_especialista, dia_semana, hora_inicio, hora_final)
VALUES (1, 1004, 3, TO_DATE('2000-01-01 08:00', 'YYYY-MM-DD HH24:MI'), TO_DATE('2000-01-01 12:00', 'YYYY-MM-DD HH24:MI'));
INSERT INTO disponibilidad_especialistas (id_sucursal, id_especialista, dia_semana, hora_inicio, hora_final)
VALUES (2, 1005, 2, TO_DATE('2000-01-01 10:00', 'YYYY-MM-DD HH24:MI'), TO_DATE('2000-01-01 15:00', 'YYYY-MM-DD HH24:MI'));
INSERT INTO disponibilidad_especialistas (id_sucursal, id_especialista, dia_semana, hora_inicio, hora_final)
VALUES (3, 1006, 2, TO_DATE('2000-01-01 09:00', 'YYYY-MM-DD HH24:MI'), TO_DATE('2000-01-01 17:00', 'YYYY-MM-DD HH24:MI'));
INSERT INTO disponibilidad_especialistas (id_sucursal, id_especialista, dia_semana, hora_inicio, hora_final)
VALUES (3, 1006, 4, TO_DATE('2000-01-01 09:00', 'YYYY-MM-DD HH24:MI'), TO_DATE('2000-01-01 17:00', 'YYYY-MM-DD HH24:MI'));

INSERT INTO ausencias_especialistas (id_especialista, fecha_inicio, fecha_fin, motivo)
VALUES (1005, DATE '2026-04-23', DATE '2026-04-24', 'Capacitacion institucional');

INSERT INTO codigos_cupon (
    id_cupon, codigo, descripcion, fecha_hora_inicio, fecha_hora_fin,
    maxima_cantidad_usos, usos_restantes, tipo_descuento, monto_descuento,
    monto_minimo_factura, esta_activo
) VALUES (
    1, 'SALUD015', 'Descuento del 15 por ciento en consulta pediatrica',
    TIMESTAMP '2026-01-01 00:00:00', TIMESTAMP '2026-12-31 23:59:59',
    100, 98, 'PORCENTAJE', 15, 20000, 1
);

INSERT INTO codigos_cupon (
    id_cupon, codigo, descripcion, fecha_hora_inicio, fecha_hora_fin,
    maxima_cantidad_usos, usos_restantes, tipo_descuento, monto_descuento,
    monto_minimo_factura, esta_activo
) VALUES (
    2, 'CARD5000', 'Monto fijo para consultas cardiologicas',
    TIMESTAMP '2026-01-01 00:00:00', TIMESTAMP '2026-06-30 23:59:59',
    50, 50, 'MONTO_FIJO', 5000, 30000, 1
);

INSERT INTO codigos_cupon (
    id_cupon, codigo, descripcion, fecha_hora_inicio, fecha_hora_fin,
    maxima_cantidad_usos, usos_restantes, tipo_descuento, monto_descuento,
    monto_minimo_factura, esta_activo
) VALUES (
    3, 'ALERGIA', 'Cupon expirado para pruebas de validacion',
    TIMESTAMP '2025-01-01 00:00:00', TIMESTAMP '2025-12-31 23:59:59',
    10, 0, 'CITA_GRATIS', 0, 0, 0
);

INSERT INTO citas (
    id_cita, id_cliente, id_sucursal, id_especialista, id_codigo_horario, fecha_cita, id_servicio, id_cupon, pudo_asistir
) VALUES (
    10000, 1003, 1, 1004, 25, DATE '2026-04-15', 2, 1, 1
);

INSERT INTO citas (
    id_cita, id_cliente, id_sucursal, id_especialista, id_codigo_horario, fecha_cita, id_servicio, id_cupon, pudo_asistir
) VALUES (
    10001, 1002, 1, 1004, 26, DATE '2026-04-15', 2, NULL, 0
);

INSERT INTO citas (
    id_cita, id_cliente, id_sucursal, id_especialista, id_codigo_horario, fecha_cita, id_servicio, id_cupon, pudo_asistir
) VALUES (
    10002, NULL, 2, 1005, 21, DATE '2026-04-20', 3, NULL, NULL
);

INSERT INTO citas (
    id_cita, id_cliente, id_sucursal, id_especialista, id_codigo_horario, fecha_cita, id_servicio, id_cupon, pudo_asistir
) VALUES (
    10003, 1007, 3, 1006, 37, DATE '2026-04-21', 1, 2, NULL
);

INSERT INTO citas (
    id_cita, id_cliente, id_sucursal, id_especialista, id_codigo_horario, fecha_cita, id_servicio, id_cupon, pudo_asistir
) VALUES (
    10004, NULL, 3, 1006, 38, DATE '2026-04-21', 1, NULL, NULL
);

INSERT INTO citas (
    id_cita, id_cliente, id_sucursal, id_especialista, id_codigo_horario, fecha_cita, id_servicio, id_cupon, pudo_asistir
) VALUES (
    10005, 1001, 3, 1006, 39, DATE '2026-04-14', 1, 3, 1
);

INSERT INTO precios_servicios (
    id_precio, id_especialista, id_servicio, fecha_inicio_vigencia, fecha_fin_vigencia, estado,
    id_moneda, precio, id_usuario_registro, fecha_hora_registro, id_usuario_aprobacion, fecha_hora_aprobacion
) VALUES (
    1, 1004, 2, TIMESTAMP '2026-01-01 00:00:00', NULL, 1,
    1, 35000, 1, TIMESTAMP '2025-12-15 10:00:00', 2, TIMESTAMP '2025-12-15 12:00:00'
);

INSERT INTO precios_servicios (
    id_precio, id_especialista, id_servicio, fecha_inicio_vigencia, fecha_fin_vigencia, estado,
    id_moneda, precio, id_usuario_registro, fecha_hora_registro, id_usuario_aprobacion, fecha_hora_aprobacion
) VALUES (
    2, 1005, 3, TIMESTAMP '2026-01-01 00:00:00', NULL, 1,
    1, 55000, 1, TIMESTAMP '2025-12-10 08:00:00', 2, TIMESTAMP '2025-12-10 09:00:00'
);

INSERT INTO precios_servicios (
    id_precio, id_especialista, id_servicio, fecha_inicio_vigencia, fecha_fin_vigencia, estado,
    id_moneda, precio, id_usuario_registro, fecha_hora_registro, id_usuario_aprobacion, fecha_hora_aprobacion
) VALUES (
    3, 1006, 1, TIMESTAMP '2026-01-01 00:00:00', NULL, 1,
    1, 28000, 1, TIMESTAMP '2025-12-18 09:30:00', 2, TIMESTAMP '2025-12-18 10:00:00'
);

INSERT INTO precios_servicios (
    id_precio, id_especialista, id_servicio, fecha_inicio_vigencia, fecha_fin_vigencia, estado,
    id_moneda, precio, id_usuario_registro, fecha_hora_registro, id_usuario_aprobacion, fecha_hora_aprobacion
) VALUES (
    4, 1006, 1, TIMESTAMP '2026-05-01 00:00:00', NULL, 0,
    1, 30000, 1, TIMESTAMP '2026-04-10 14:00:00', NULL, NULL
);

INSERT INTO facturacion (
    id_factura, id_cita, fecha_hora_facturacion, monto_bruto, monto_descuento, monto_impuesto, monto_total
) VALUES (
    1, 10000, TIMESTAMP '2026-04-15 08:40:00', 35000, 5250, 3867.50, 33617.50
);

INSERT INTO facturacion (
    id_factura, id_cita, fecha_hora_facturacion, monto_bruto, monto_descuento, monto_impuesto, monto_total
) VALUES (
    2, 10005, TIMESTAMP '2026-04-14 09:50:00', 28000, 0, 3640, 31640
);

COMMIT;

PROMPT Esquema y datos creados correctamente.
