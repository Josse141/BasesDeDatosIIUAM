PROMPT ============================================================
PROMPT 03 - Funciones para calculo del monto total de facturacion
PROMPT ============================================================

CREATE OR REPLACE FUNCTION fn_obtener_precio_vigente (
    p_id_especialista IN NUMBER,
    p_id_servicio     IN NUMBER,
    p_fecha_cita      IN TIMESTAMP
) RETURN NUMBER
IS
    v_precio NUMBER(10,2);
BEGIN
    SELECT precio
      INTO v_precio
      FROM (
            SELECT ps.precio
              FROM precios_servicios ps
             WHERE ps.id_especialista = p_id_especialista
               AND ps.id_servicio = p_id_servicio
               AND ps.estado = 1
               AND ps.fecha_inicio_vigencia <= p_fecha_cita
               AND (ps.fecha_fin_vigencia IS NULL OR ps.fecha_fin_vigencia > p_fecha_cita)
             ORDER BY ps.fecha_inicio_vigencia DESC
           )
     WHERE ROWNUM = 1;

    RETURN v_precio;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(
            -20001,
            'No existe un precio aprobado y vigente para el especialista ' || p_id_especialista
            || ' y el servicio ' || p_id_servicio
        );
END;
/

CREATE OR REPLACE FUNCTION fn_calcular_descuento_cupon (
    p_id_cupon      IN NUMBER,
    p_monto_bruto   IN NUMBER,
    p_fecha_cita    IN TIMESTAMP
) RETURN NUMBER
IS
    v_tipo_descuento       codigos_cupon.tipo_descuento%TYPE;
    v_monto_descuento      codigos_cupon.monto_descuento%TYPE;
    v_monto_minimo         codigos_cupon.monto_minimo_factura%TYPE;
    v_esta_activo          codigos_cupon.esta_activo%TYPE;
    v_fecha_inicio         codigos_cupon.fecha_hora_inicio%TYPE;
    v_fecha_fin            codigos_cupon.fecha_hora_fin%TYPE;
    v_usos_restantes       codigos_cupon.usos_restantes%TYPE;
    v_descuento            NUMBER(10,2) := 0;
BEGIN
    IF p_id_cupon IS NULL THEN
        RETURN 0;
    END IF;

    SELECT
        tipo_descuento,
        monto_descuento,
        monto_minimo_factura,
        esta_activo,
        fecha_hora_inicio,
        fecha_hora_fin,
        usos_restantes
    INTO
        v_tipo_descuento,
        v_monto_descuento,
        v_monto_minimo,
        v_esta_activo,
        v_fecha_inicio,
        v_fecha_fin,
        v_usos_restantes
    FROM codigos_cupon
    WHERE id_cupon = p_id_cupon;

    IF v_esta_activo = 0
       OR p_fecha_cita < v_fecha_inicio
       OR p_fecha_cita > v_fecha_fin
       OR v_usos_restantes <= 0
       OR p_monto_bruto < v_monto_minimo THEN
        RETURN 0;
    END IF;

    IF v_tipo_descuento = 'PORCENTAJE' THEN
        v_descuento := ROUND(p_monto_bruto * (v_monto_descuento / 100), 2);
    ELSIF v_tipo_descuento = 'MONTO_FIJO' THEN
        v_descuento := LEAST(v_monto_descuento, p_monto_bruto);
    ELSIF v_tipo_descuento = 'CITA_GRATIS' THEN
        v_descuento := p_monto_bruto;
    ELSIF v_tipo_descuento = 'BONO' THEN
        v_descuento := LEAST(v_monto_descuento, p_monto_bruto);
    END IF;

    RETURN ROUND(v_descuento, 2);
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20002, 'El codigo de cupon ' || p_id_cupon || ' no existe.');
END;
/

CREATE OR REPLACE FUNCTION fn_calcular_impuesto (
    p_id_servicio      IN NUMBER,
    p_subtotal_neto    IN NUMBER
) RETURN NUMBER
IS
    v_porcentaje_impuesto servicios.porcentaje_impuesto%TYPE;
BEGIN
    SELECT porcentaje_impuesto
      INTO v_porcentaje_impuesto
      FROM servicios
     WHERE id_servicio = p_id_servicio;

    RETURN ROUND(p_subtotal_neto * (v_porcentaje_impuesto / 100), 2);
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20003, 'El servicio ' || p_id_servicio || ' no existe.');
END;
/

CREATE OR REPLACE FUNCTION fn_calcular_total_factura (
    p_id_cita IN NUMBER
) RETURN NUMBER
IS
    v_id_especialista   citas.id_especialista%TYPE;
    v_id_servicio       citas.id_servicio%TYPE;
    v_id_cupon          citas.id_cupon%TYPE;
    v_id_sucursal       citas.id_sucursal%TYPE;
    v_id_codigo_horario citas.id_codigo_horario%TYPE;
    v_id_tipo_horario   sucursales.id_tipo_horario%TYPE;
    v_hora_inicial      codigos_horario.hora_inicial%TYPE;
    v_fecha_cita        citas.fecha_cita%TYPE;
    v_fecha_hora_cita   TIMESTAMP;
    v_monto_bruto       NUMBER(10,2);
    v_monto_descuento   NUMBER(10,2);
    v_subtotal_neto     NUMBER(10,2);
    v_monto_impuesto    NUMBER(10,2);
BEGIN
    SELECT
        c.id_especialista,
        c.id_servicio,
        c.id_cupon,
        c.id_sucursal,
        c.id_codigo_horario,
        c.fecha_cita
    INTO
        v_id_especialista,
        v_id_servicio,
        v_id_cupon,
        v_id_sucursal,
        v_id_codigo_horario,
        v_fecha_cita
    FROM citas c
    WHERE c.id_cita = p_id_cita;

    BEGIN
        SELECT id_tipo_horario
          INTO v_id_tipo_horario
          FROM sucursales
         WHERE id_sucursal = v_id_sucursal;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RAISE_APPLICATION_ERROR(-20005, 'La sucursal asociada a la cita ' || p_id_cita || ' no existe.');
    END;

    BEGIN
        SELECT hora_inicial
          INTO v_hora_inicial
          FROM codigos_horario
         WHERE id_tipo_horario = v_id_tipo_horario
           AND id_codigo_horario = v_id_codigo_horario;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RAISE_APPLICATION_ERROR(
                -20006,
                'No existe configuracion de codigo horario para la cita ' || p_id_cita
            );
    END;

    v_fecha_hora_cita := TO_TIMESTAMP(
        TO_CHAR(v_fecha_cita, 'YYYY-MM-DD') || ' ' || TO_CHAR(v_hora_inicial, 'HH24:MI'),
        'YYYY-MM-DD HH24:MI'
    );

    v_monto_bruto := fn_obtener_precio_vigente(v_id_especialista, v_id_servicio, v_fecha_hora_cita);
    v_monto_descuento := fn_calcular_descuento_cupon(v_id_cupon, v_monto_bruto, v_fecha_hora_cita);
    v_subtotal_neto := v_monto_bruto - v_monto_descuento;
    v_monto_impuesto := fn_calcular_impuesto(v_id_servicio, v_subtotal_neto);

    RETURN ROUND(v_subtotal_neto + v_monto_impuesto, 2);
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20004, 'La cita ' || p_id_cita || ' no existe.');
END;
/

PROMPT Funciones creadas correctamente.
