SET SERVEROUTPUT ON;
ALTER SESSION SET NLS_DATE_FORMAT = 'YYYY-MM-DD';

PROMPT ==========================================
PROMPT PRUEBAS DEL PROCEDIMIENTO 1
PROMPT sp_process_payroll_person_data
PROMPT ==========================================

BEGIN
    DELETE FROM my_work_payment_detail
    WHERE time_period IN (DATE '2025-01-01', DATE '2025-02-01', DATE '2025-03-01');

    UPDATE my_work_accounts
    SET current_balance = CASE account_id
        WHEN '001-001' THEN 1000
        WHEN '001-002' THEN 5000
        WHEN '002-001' THEN 5000
        WHEN '002-002' THEN 3000
        ELSE current_balance
    END;

    COMMIT;
END;
/

PROMPT Caso 1.1 - Persona con salario negativo
BEGIN
    sp_process_payroll_person_data(DATE '2025-01-01', 101, -5, 40, 2, 1, 1);
END;
/

SELECT *
FROM my_work_payment_detail
WHERE person_id = 101
  AND time_period = DATE '2025-01-01';

PROMPT Caso 1.2 - Persona con salario cero
BEGIN
    sp_process_payroll_person_data(DATE '2025-02-01', 102, 0, 40, 2, 1, 1);
END;
/

SELECT *
FROM my_work_payment_detail
WHERE person_id = 102
  AND time_period = DATE '2025-02-01';

PROMPT Caso 1.3 - Persona positiva con llamado directo
BEGIN
    sp_process_payroll_person_data(DATE '2025-03-01', 104, 10, 40, 1, 1, 1);
END;
/

SELECT *
FROM my_work_payment_detail
WHERE person_id = 104
  AND time_period = DATE '2025-03-01';

SELECT account_id, current_balance
FROM my_work_accounts
ORDER BY account_id;

PROMPT ==========================================
PROMPT PRUEBAS DEL PROCEDIMIENTO 2
PROMPT sp_process_payroll_person
PROMPT ==========================================

PROMPT Caso 2.1 - Persona ya pagada
BEGIN
    UPDATE my_work_accounts
    SET current_balance = CASE account_id
        WHEN '001-001' THEN 1000
        WHEN '001-002' THEN 5000
        WHEN '002-001' THEN 5000
        WHEN '002-002' THEN 3000
        ELSE current_balance
    END;
    COMMIT;
END;
/

BEGIN
    sp_process_payroll_person(DATE '2024-03-01', 103);
END;
/

SELECT *
FROM my_work_payment_detail
WHERE person_id = 103
  AND time_period = DATE '2024-03-01';

PROMPT Caso 2.2 - Se paga el salario neto exitosamente
BEGIN
    DELETE FROM my_work_payment_detail WHERE person_id = 104 AND time_period = DATE '2024-04-01';

    UPDATE my_work_accounts
    SET current_balance = CASE account_id
        WHEN '001-001' THEN 1000
        WHEN '001-002' THEN 5000
        WHEN '002-001' THEN 5000
        WHEN '002-002' THEN 3000
        ELSE current_balance
    END;
    COMMIT;
END;
/

BEGIN
    sp_process_payroll_person(DATE '2024-04-01', 104);
END;
/

SELECT *
FROM my_work_payment_detail
WHERE person_id = 104
  AND time_period = DATE '2024-04-01';

SELECT account_id, current_balance
FROM my_work_accounts
ORDER BY account_id;

PROMPT Caso 2.3 - NO se paga el salario neto por falta de fondos
BEGIN
    DELETE FROM my_work_payment_detail WHERE person_id = 105 AND time_period = DATE '2024-05-01';

    UPDATE my_work_accounts
    SET current_balance = CASE account_id
        WHEN '001-001' THEN 1000
        WHEN '001-002' THEN 5000
        WHEN '002-001' THEN 1000
        WHEN '002-002' THEN 3000
        ELSE current_balance
    END;
    COMMIT;
END;
/

BEGIN
    sp_process_payroll_person(DATE '2024-05-01', 105);
END;
/

SELECT *
FROM my_work_payment_detail
WHERE person_id = 105
  AND time_period = DATE '2024-05-01';

SELECT account_id, current_balance
FROM my_work_accounts
ORDER BY account_id;

PROMPT Caso 2.4 - Se rebajan las horas donadas exitosamente
BEGIN
    DELETE FROM my_work_payment_detail WHERE person_id = 106 AND time_period = DATE '2024-06-01';

    UPDATE my_work_accounts
    SET current_balance = CASE account_id
        WHEN '001-001' THEN 1000
        WHEN '001-002' THEN 5000
        WHEN '002-001' THEN 5000
        WHEN '002-002' THEN 3000
        ELSE current_balance
    END;
    COMMIT;
END;
/

BEGIN
    sp_process_payroll_person(DATE '2024-06-01', 106);
END;
/

SELECT *
FROM my_work_payment_detail
WHERE person_id = 106
  AND time_period = DATE '2024-06-01';

SELECT account_id, current_balance
FROM my_work_accounts
ORDER BY account_id;

PROMPT Caso 2.5 - NO se rebajan las horas donadas por falta de fondos
BEGIN
    DELETE FROM my_work_payment_detail WHERE person_id = 107 AND time_period = DATE '2024-07-01';

    UPDATE my_work_accounts
    SET current_balance = CASE account_id
        WHEN '001-001' THEN 1000
        WHEN '001-002' THEN 50
        WHEN '002-001' THEN 5000
        WHEN '002-002' THEN 3000
        ELSE current_balance
    END;
    COMMIT;
END;
/

BEGIN
    sp_process_payroll_person(DATE '2024-07-01', 107);
END;
/

SELECT *
FROM my_work_payment_detail
WHERE person_id = 107
  AND time_period = DATE '2024-07-01';

SELECT account_id, current_balance
FROM my_work_accounts
ORDER BY account_id;

PROMPT Caso 2.6 - Se acreditan las horas extras exitosamente
BEGIN
    DELETE FROM my_work_payment_detail WHERE person_id = 108 AND time_period = DATE '2024-08-01';

    UPDATE my_work_accounts
    SET current_balance = CASE account_id
        WHEN '001-001' THEN 1000
        WHEN '001-002' THEN 5000
        WHEN '002-001' THEN 5000
        WHEN '002-002' THEN 500
        ELSE current_balance
    END;
    COMMIT;
END;
/

BEGIN
    sp_process_payroll_person(DATE '2024-08-01', 108);
END;
/

SELECT *
FROM my_work_payment_detail
WHERE person_id = 108
  AND time_period = DATE '2024-08-01';

SELECT account_id, current_balance
FROM my_work_accounts
ORDER BY account_id;

PROMPT Caso 2.7 - NO se acreditan las horas extras por falta de fondos
BEGIN
    DELETE FROM my_work_payment_detail WHERE person_id = 109 AND time_period = DATE '2024-09-01';

    UPDATE my_work_accounts
    SET current_balance = CASE account_id
        WHEN '001-001' THEN 1000
        WHEN '001-002' THEN 5000
        WHEN '002-001' THEN 5000
        WHEN '002-002' THEN 100
        ELSE current_balance
    END;
    COMMIT;
END;
/

BEGIN
    sp_process_payroll_person(DATE '2024-09-01', 109);
END;
/

SELECT *
FROM my_work_payment_detail
WHERE person_id = 109
  AND time_period = DATE '2024-09-01';

SELECT account_id, current_balance
FROM my_work_accounts
ORDER BY account_id;

PROMPT Caso 2.8 - Se acreditan las horas super extras exitosamente
BEGIN
    DELETE FROM my_work_payment_detail WHERE person_id = 110 AND time_period = DATE '2024-10-01';

    UPDATE my_work_accounts
    SET current_balance = CASE account_id
        WHEN '001-001' THEN 1000
        WHEN '001-002' THEN 5000
        WHEN '002-001' THEN 5000
        WHEN '002-002' THEN 500
        ELSE current_balance
    END;
    COMMIT;
END;
/

BEGIN
    sp_process_payroll_person(DATE '2024-10-01', 110);
END;
/

SELECT *
FROM my_work_payment_detail
WHERE person_id = 110
  AND time_period = DATE '2024-10-01';

SELECT account_id, current_balance
FROM my_work_accounts
ORDER BY account_id;

PROMPT Caso 2.9 - NO se acreditan las horas super extras por falta de fondos
BEGIN
    DELETE FROM my_work_payment_detail WHERE person_id = 111 AND time_period = DATE '2024-11-01';

    UPDATE my_work_accounts
    SET current_balance = CASE account_id
        WHEN '001-001' THEN 1000
        WHEN '001-002' THEN 5000
        WHEN '002-001' THEN 5000
        WHEN '002-002' THEN 150
        ELSE current_balance
    END;
    COMMIT;
END;
/

BEGIN
    sp_process_payroll_person(DATE '2024-11-01', 111);
END;
/

SELECT *
FROM my_work_payment_detail
WHERE person_id = 111
  AND time_period = DATE '2024-11-01';

SELECT account_id, current_balance
FROM my_work_accounts
ORDER BY account_id;

PROMPT ==========================================
PROMPT PRUEBA DEL PROCEDIMIENTO 3
PROMPT sp_process_payroll_period
PROMPT ==========================================

BEGIN
    DELETE FROM my_work_payment_detail WHERE time_period = DATE '2024-12-01';

    UPDATE my_work_accounts
    SET current_balance = CASE account_id
        WHEN '001-001' THEN 1000
        WHEN '001-002' THEN 5000
        WHEN '002-001' THEN 10000
        WHEN '002-002' THEN 5000
        ELSE current_balance
    END;
    COMMIT;
END;
/

BEGIN
    sp_process_payroll_period(DATE '2024-12-01');
END;
/

SELECT *
FROM my_work_payment_detail
WHERE time_period = DATE '2024-12-01'
ORDER BY person_id;

SELECT account_id, current_balance
FROM my_work_accounts
ORDER BY account_id;
