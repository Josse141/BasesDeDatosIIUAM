📊 Oracle Payroll System (PL/SQL)
📖 Description

This project implements a payroll processing system using Oracle SQL and PL/SQL. It includes scripts for schema creation, data loading, processing logic, and testing.

⚙️ Requirements
Oracle Database (recommended 11g or higher)
SQL*Plus / SQL Developer / compatible client
Permissions to create tables, procedures, and insert data
🚀 Execution Instructions

You have two options depending on your environment:

🔹 Option 1: Run All Scripts Automatically

If your environment supports executing scripts that call others:

@ejecutar_planilla_empresa_oracle.sql

🔹 Option 2: Run Scripts Manually

Execute the scripts in the following order:

@crear_planilla_empresa_oracle.sql
@cargar_datos_planilla_empresa_oracle.sql
@procesar_planilla_empresa_oracle.sql
@probar_planilla_empresa_oracle.sql
🧪 Testing

All test cases are included in:

probar_planilla_empresa_oracle.sql

This script validates the functionality of the payroll processing logic.

📁 Project Structure
.
├── crear_planilla_empresa_oracle.sql
├── cargar_datos_planilla_empresa_oracle.sql
├── procesar_planilla_empresa_oracle.sql
├── probar_planilla_empresa_oracle.sql
├── ejecutar_planilla_empresa_oracle.sql
👤 Author

Jose Alonso Mora Artavia