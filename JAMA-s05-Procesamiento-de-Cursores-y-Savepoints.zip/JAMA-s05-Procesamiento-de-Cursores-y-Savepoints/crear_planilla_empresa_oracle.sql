SET SERVEROUTPUT ON;

BEGIN
    EXECUTE IMMEDIATE 'DROP TABLE my_work_payment_detail CASCADE CONSTRAINTS';
EXCEPTION
    WHEN OTHERS THEN
        IF SQLCODE != -942 THEN
            RAISE;
        END IF;
END;
/

BEGIN
    EXECUTE IMMEDIATE 'DROP TABLE my_work_payment_info CASCADE CONSTRAINTS';
EXCEPTION
    WHEN OTHERS THEN
        IF SQLCODE != -942 THEN
            RAISE;
        END IF;
END;
/

BEGIN
    EXECUTE IMMEDIATE 'DROP TABLE my_work_employees CASCADE CONSTRAINTS';
EXCEPTION
    WHEN OTHERS THEN
        IF SQLCODE != -942 THEN
            RAISE;
        END IF;
END;
/

BEGIN
    EXECUTE IMMEDIATE 'DROP TABLE my_work_accounts CASCADE CONSTRAINTS';
EXCEPTION
    WHEN OTHERS THEN
        IF SQLCODE != -942 THEN
            RAISE;
        END IF;
END;
/

CREATE TABLE my_work_employees (
    person_id     NUMBER        NOT NULL,
    person_name   VARCHAR2(120) NOT NULL,
    hour_salary   NUMBER(12,2)  NOT NULL,
    CONSTRAINT pk_my_work_employees PRIMARY KEY (person_id)
);

CREATE TABLE my_work_payment_info (
    person_id            NUMBER       NOT NULL,
    time_period          DATE         NOT NULL,
    worked_hours         NUMBER(10,2) DEFAULT 0 NOT NULL,
    extra_hours          NUMBER(10,2) DEFAULT 0 NOT NULL,
    super_extra_hours    NUMBER(10,2) DEFAULT 0 NOT NULL,
    donated_hours        NUMBER(10,2) DEFAULT 0 NOT NULL,
    CONSTRAINT pk_my_work_payment_info PRIMARY KEY (person_id, time_period),
    CONSTRAINT fk_payment_info_employee
        FOREIGN KEY (person_id) REFERENCES my_work_employees (person_id)
);

CREATE TABLE my_work_payment_detail (
    person_id               NUMBER       NOT NULL,
    time_period             DATE         NOT NULL,
    worked_status           CHAR(1)      DEFAULT 'I' NOT NULL,
    worked_amount           NUMBER(12,2) DEFAULT 0 NOT NULL,
    extra_status            CHAR(1)      DEFAULT 'I' NOT NULL,
    extra_amount            NUMBER(12,2) DEFAULT 0 NOT NULL,
    super_extra_amount      NUMBER(12,2) DEFAULT 0 NOT NULL,
    donated_status          CHAR(1)      DEFAULT 'I' NOT NULL,
    donated_amount          NUMBER(12,2) DEFAULT 0 NOT NULL,
    final_status            CHAR(1)      DEFAULT 'I' NOT NULL,
    processed_at            DATE         DEFAULT SYSDATE NOT NULL,
    CONSTRAINT pk_my_work_payment_detail PRIMARY KEY (person_id, time_period),
    CONSTRAINT fk_payment_detail_employee
        FOREIGN KEY (person_id) REFERENCES my_work_employees (person_id),
    CONSTRAINT ck_payment_detail_worked_status
        CHECK (worked_status IN ('C', 'I')),
    CONSTRAINT ck_payment_detail_extra_status
        CHECK (extra_status IN ('C', 'I')),
    CONSTRAINT ck_payment_detail_donated_status
        CHECK (donated_status IN ('C', 'I')),
    CONSTRAINT ck_payment_detail_final_status
        CHECK (final_status IN ('C', 'I'))
);

CREATE TABLE my_work_accounts (
    account_id        VARCHAR2(20)  NOT NULL,
    current_balance   NUMBER(14,2)  NOT NULL,
    CONSTRAINT pk_my_work_accounts PRIMARY KEY (account_id),
    CONSTRAINT ck_my_work_accounts_balance
        CHECK (current_balance >= 0)
);

BEGIN
    DBMS_OUTPUT.PUT_LINE('Tablas de planilla creadas correctamente.');
END;
/
