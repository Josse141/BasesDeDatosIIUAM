SET SERVEROUTPUT ON;

BEGIN
    DELETE FROM my_work_payment_detail
    WHERE person_id BETWEEN 1 AND 100
      AND time_period BETWEEN DATE '2022-01-01' AND DATE '2024-12-01';

    DELETE FROM my_work_payment_info
    WHERE person_id BETWEEN 1 AND 100
      AND time_period BETWEEN DATE '2022-01-01' AND DATE '2024-12-01';

    DELETE FROM my_work_employees
    WHERE person_id BETWEEN 1 AND 100;

    COMMIT;
END;
/

BEGIN
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (1, 'Alice Johnson', 25.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (2, 'Bob Smith', 30.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (3, 'Carol Taylor', 22.50);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (4, 'David Brown', 28.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (5, 'Eva White', 27.50);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (6, 'Frank Green', 24.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (7, 'Grace Hall', 26.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (8, 'Hank Moore', 29.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (9, 'Ivy Wilson', 23.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (10, 'Jack Harris', 31.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (11, 'Karen Clark', 25.50);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (12, 'Leon Scott', 28.50);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (13, 'Mona Lewis', 29.50);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (14, 'Nina Walker', 27.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (15, 'Oscar Young', 26.50);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (16, 'Paul King', 30.50);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (17, 'Quinn Wright', 24.50);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (18, 'Rita Hill', 22.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (19, 'Steve Adams', 31.50);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (20, 'Tina Green', 29.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (21, 'Uma Nelson', 26.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (22, 'Vera Carter', 23.50);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (23, 'Will Mitchell', 21.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (24, 'Xena Perez', 28.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (25, 'Yara Roberts', 30.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (26, 'Zane Turner', 25.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (27, 'Abby Reed', 24.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (28, 'Brad Foster', 27.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (29, 'Cathy Gray', 29.50);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (30, 'Derek Hughes', 28.50);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (31, 'Eva Martinez', 26.50);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (32, 'Finn Powell', 22.50);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (33, 'Gina Flores', 23.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (34, 'Hugo Diaz', 30.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (35, 'Isla Ramirez', 29.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (36, 'Jackie Griffin', 27.50);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (37, 'Kirk Adams', 24.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (38, 'Lara Lane', 25.50);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (39, 'Mia different', 31.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (40, 'Nate Perez', 23.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (41, 'Olivia Miller', 26.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (42, 'Pauline Scott', 27.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (43, 'Reed fitness', 29.50);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (44, 'Sandra Allen', 30.50);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (45, 'Trevor Moore', 22.50);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (46, 'Umberto Johnson', 25.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (47, 'Vicky Turner', 24.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (48, 'Winston Parker', 28.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (49, 'Xander Lewis', 29.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (50, 'Yvonne Edwards', 26.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (51, 'Zoe Hall', 30.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (52, 'Aaron Martin', 27.50);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (53, 'Brittany Harper', 29.50);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (54, 'Chris Kelley', 28.50);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (55, 'Diana Knight', 26.50);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (56, 'Edward Lopez', 31.50);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (57, 'Florence Gonzalez', 25.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (58, 'George Rivera', 24.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (59, 'Holly Simmons', 23.50);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (60, 'Ian Rogers', 30.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (61, 'Jessica Long', 28.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (62, 'Kevin Ward', 27.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (63, 'Laura Tran', 26.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (64, 'Mark Torres', 29.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (65, 'Nancy Parker', 22.50);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (66, 'Oscar Brooks', 30.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (67, 'Pamela Sanchez', 23.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (68, 'Quincy Bennett', 28.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (69, 'Rachael Murphy', 27.50);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (70, 'Sammy Hughes', 24.50);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (71, 'Teresa Cox', 29.50);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (72, 'Ulysses Bell', 31.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (73, 'Vivian Reed', 26.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (74, 'Walter Powell', 22.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (75, 'Xena Collins', 23.50);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (76, 'Yosef Bennett', 29.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (77, 'Zora King', 28.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (78, 'Amy Lee', 26.50);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (79, 'Brian Wood', 24.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (80, 'Claire Young', 30.50);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (81, 'David Eng', 27.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (82, 'Ella Wright', 29.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (83, 'Felix Castro', 31.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (84, 'Gina Kelly', 22.50);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (85, 'Harry Diaz', 30.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (86, 'Ivy Morrison', 25.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (87, 'Jordan Walsh', 28.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (88, 'Kathy Simmons', 26.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (89, 'Leonard Price', 29.50);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (90, 'Monica Campbell', 30.50);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (91, 'Nick Jordan', 23.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (92, 'Olive Martinez', 24.50);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (93, 'Paulina Cole', 25.50);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (94, 'Quin McDonald', 22.50);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (95, 'Ray Nichols', 28.50);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (96, 'Sunny Reed', 30.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (97, 'Timothy Lopez', 29.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (98, 'Ursula Wong', 27.50);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (99, 'Victor Hunter', 31.00);
    INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (100, 'Wendy Price', 25.00);
    COMMIT;
END;
/

DECLARE
    v_person_id           NUMBER;
    v_worked_hours        NUMBER;
    v_extra_hours         NUMBER;
    v_super_extra_hours   NUMBER;
    v_donated_hours       NUMBER;
    v_time_period         DATE;
BEGIN
    DBMS_RANDOM.SEED(20240411);

    FOR v_year IN 2022 .. 2024 LOOP
        FOR v_month IN 1 .. 12 LOOP
            v_person_id := TRUNC(DBMS_RANDOM.VALUE(1, 101));
            v_worked_hours := TRUNC(DBMS_RANDOM.VALUE(30, 49));

            v_extra_hours := CASE
                WHEN DBMS_RANDOM.VALUE(0, 1) < 0.15 THEN 0
                ELSE TRUNC(DBMS_RANDOM.VALUE(0, 11))
            END;

            v_super_extra_hours := CASE
                WHEN DBMS_RANDOM.VALUE(0, 1) < 0.40 THEN 0
                ELSE TRUNC(DBMS_RANDOM.VALUE(0, 11))
            END;

            v_donated_hours := TRUNC(DBMS_RANDOM.VALUE(0, 11));
            v_time_period := TO_DATE(v_year || LPAD(v_month, 2, '0') || '01', 'YYYYMMDD');

            INSERT INTO my_work_payment_info (
                person_id,
                time_period,
                worked_hours,
                extra_hours,
                super_extra_hours,
                donated_hours
            ) VALUES (
                v_person_id,
                v_time_period,
                v_worked_hours,
                v_extra_hours,
                v_super_extra_hours,
                v_donated_hours
            );
        END LOOP;
    END LOOP;

    COMMIT;
END;
/

PROMPT ==========================================
PROMPT DATOS MASIVOS DE PRUEBA CARGADOS
PROMPT ==========================================

SELECT COUNT(*) AS total_employees_loaded
FROM my_work_employees
WHERE person_id BETWEEN 1 AND 100;

SELECT COUNT(*) AS total_payment_rows_loaded
FROM my_work_payment_info
WHERE person_id BETWEEN 1 AND 100
  AND time_period BETWEEN DATE '2022-01-01' AND DATE '2024-12-01';
