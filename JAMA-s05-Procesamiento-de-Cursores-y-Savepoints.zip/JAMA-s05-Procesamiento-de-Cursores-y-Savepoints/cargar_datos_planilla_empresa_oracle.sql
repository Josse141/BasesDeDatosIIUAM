SET SERVEROUTPUT ON;

INSERT INTO my_work_accounts (account_id, current_balance) VALUES ('001-001', 1000);
INSERT INTO my_work_accounts (account_id, current_balance) VALUES ('001-002', 5000);
INSERT INTO my_work_accounts (account_id, current_balance) VALUES ('002-001', 20000);
INSERT INTO my_work_accounts (account_id, current_balance) VALUES ('002-002', 10000);

INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (101, 'Adriana Salario Negativo', -5);
INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (102, 'Bruno Practicante', 0);
INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (103, 'Carla Ya Pagada', 20);
INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (104, 'Daniel Neto Exitoso', 10);
INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (105, 'Elena Neto Sin Fondos', 50);
INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (106, 'Fabian Donacion Exitosa', 20);
INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (107, 'Gabriela Donacion Sin Fondos', 20);
INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (108, 'Hector Extras Exitosos', 20);
INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (109, 'Ines Extras Sin Fondos', 30);
INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (110, 'Jorge Super Extras Exitosos', 20);
INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (111, 'Karla Super Extras Sin Fondos', 20);
INSERT INTO my_work_employees (person_id, person_name, hour_salary) VALUES (112, 'Luis Lote Mixto', 18);

INSERT INTO my_work_payment_info (person_id, time_period, worked_hours, extra_hours, super_extra_hours, donated_hours)
VALUES (101, DATE '2024-01-01', 40, 5, 2, 1);

INSERT INTO my_work_payment_info (person_id, time_period, worked_hours, extra_hours, super_extra_hours, donated_hours)
VALUES (102, DATE '2024-02-01', 40, 5, 2, 1);

INSERT INTO my_work_payment_info (person_id, time_period, worked_hours, extra_hours, super_extra_hours, donated_hours)
VALUES (103, DATE '2024-03-01', 40, 2, 1, 1);

INSERT INTO my_work_payment_info (person_id, time_period, worked_hours, extra_hours, super_extra_hours, donated_hours)
VALUES (104, DATE '2024-04-01', 40, 0, 0, 2);

INSERT INTO my_work_payment_info (person_id, time_period, worked_hours, extra_hours, super_extra_hours, donated_hours)
VALUES (105, DATE '2024-05-01', 40, 0, 0, 2);

INSERT INTO my_work_payment_info (person_id, time_period, worked_hours, extra_hours, super_extra_hours, donated_hours)
VALUES (106, DATE '2024-06-01', 40, 0, 0, 3);

INSERT INTO my_work_payment_info (person_id, time_period, worked_hours, extra_hours, super_extra_hours, donated_hours)
VALUES (107, DATE '2024-07-01', 40, 0, 0, 4);

INSERT INTO my_work_payment_info (person_id, time_period, worked_hours, extra_hours, super_extra_hours, donated_hours)
VALUES (108, DATE '2024-08-01', 40, 4, 0, 0);

INSERT INTO my_work_payment_info (person_id, time_period, worked_hours, extra_hours, super_extra_hours, donated_hours)
VALUES (109, DATE '2024-09-01', 40, 5, 0, 0);

INSERT INTO my_work_payment_info (person_id, time_period, worked_hours, extra_hours, super_extra_hours, donated_hours)
VALUES (110, DATE '2024-10-01', 40, 2, 3, 0);

INSERT INTO my_work_payment_info (person_id, time_period, worked_hours, extra_hours, super_extra_hours, donated_hours)
VALUES (111, DATE '2024-11-01', 40, 2, 5, 0);

INSERT INTO my_work_payment_info (person_id, time_period, worked_hours, extra_hours, super_extra_hours, donated_hours)
VALUES (101, DATE '2024-12-01', 40, 0, 0, 1);

INSERT INTO my_work_payment_info (person_id, time_period, worked_hours, extra_hours, super_extra_hours, donated_hours)
VALUES (102, DATE '2024-12-01', 40, 0, 0, 1);

INSERT INTO my_work_payment_info (person_id, time_period, worked_hours, extra_hours, super_extra_hours, donated_hours)
VALUES (104, DATE '2024-12-01', 40, 1, 0, 1);

INSERT INTO my_work_payment_info (person_id, time_period, worked_hours, extra_hours, super_extra_hours, donated_hours)
VALUES (112, DATE '2024-12-01', 35, 2, 1, 0.5);

INSERT INTO my_work_payment_detail (
    person_id,
    time_period,
    worked_status,
    worked_amount,
    extra_status,
    extra_amount,
    super_extra_amount,
    donated_status,
    donated_amount,
    final_status,
    processed_at
) VALUES (
    103,
    DATE '2024-03-01',
    'C',
    780,
    'C',
    60,
    40,
    'C',
    20,
    'C',
    SYSDATE - 1
);

COMMIT;

BEGIN
    DBMS_OUTPUT.PUT_LINE('Datos iniciales de planilla cargados correctamente.');
END;
/
