SET SERVEROUTPUT ON;
ALTER SESSION SET NLS_DATE_FORMAT = 'YYYY-MM-DD';

PROMPT ==========================================
PROMPT CREANDO ESQUEMA DE PLANILLA
PROMPT ==========================================
@crear_planilla_empresa_oracle.sql

PROMPT ==========================================
PROMPT CARGANDO DATOS INICIALES
PROMPT ==========================================
@cargar_datos_planilla_empresa_oracle.sql

PROMPT ==========================================
PROMPT CREANDO PROCEDIMIENTOS
PROMPT ==========================================
@procesar_planilla_empresa_oracle.sql

PROMPT ==========================================
PROMPT EJECUTANDO PRUEBAS
PROMPT ==========================================
@probar_planilla_empresa_oracle.sql
