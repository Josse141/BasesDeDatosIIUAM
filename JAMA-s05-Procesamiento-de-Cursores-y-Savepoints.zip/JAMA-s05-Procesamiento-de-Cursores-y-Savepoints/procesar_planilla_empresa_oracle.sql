SET SERVEROUTPUT ON;

CREATE OR REPLACE PROCEDURE sp_process_payroll_person_data (
    p_time_period         IN DATE,
    p_person_id           IN NUMBER,
    p_hour_salary         IN NUMBER,
    p_worked_hours        IN NUMBER,
    p_extra_hours         IN NUMBER,
    p_super_extra_hours   IN NUMBER,
    p_donated_hours       IN NUMBER
)
AS
    c_foundation_account         CONSTANT VARCHAR2(20) := '001-001';
    c_foundation_company_account CONSTANT VARCHAR2(20) := '001-002';
    c_worked_account             CONSTANT VARCHAR2(20) := '002-001';
    c_extra_account              CONSTANT VARCHAR2(20) := '002-002';

    v_employee_count         NUMBER;
    v_worked_status          CHAR(1);
    v_worked_amount          NUMBER(12,2);
    v_extra_status           CHAR(1);
    v_extra_amount           NUMBER(12,2);
    v_super_extra_amount     NUMBER(12,2);
    v_donated_status         CHAR(1);
    v_donated_amount         NUMBER(12,2);
    v_final_status           CHAR(1);
    v_effective_donation     NUMBER(12,2);

    PROCEDURE credit_account (
        p_account_id IN VARCHAR2,
        p_amount     IN NUMBER
    )
    AS
    BEGIN
        IF NVL(p_amount, 0) = 0 THEN
            RETURN;
        END IF;

        UPDATE my_work_accounts
        SET current_balance = current_balance + p_amount
        WHERE account_id = p_account_id;

        IF SQL%ROWCOUNT = 0 THEN
            RAISE_APPLICATION_ERROR(-20010, 'No existe la cuenta ' || p_account_id || '.');
        END IF;
    END;

    PROCEDURE debit_account (
        p_account_id IN VARCHAR2,
        p_amount     IN NUMBER
    )
    AS
    BEGIN
        IF NVL(p_amount, 0) = 0 THEN
            RETURN;
        END IF;

        UPDATE my_work_accounts
        SET current_balance = current_balance - p_amount
        WHERE account_id = p_account_id;

        IF SQL%ROWCOUNT = 0 THEN
            RAISE_APPLICATION_ERROR(-20011, 'No existe la cuenta ' || p_account_id || '.');
        END IF;
    END;
BEGIN
    IF p_time_period IS NULL THEN
        RAISE_APPLICATION_ERROR(-20001, 'El periodo es obligatorio.');
    END IF;

    IF p_person_id IS NULL THEN
        RAISE_APPLICATION_ERROR(-20002, 'La persona es obligatoria.');
    END IF;

    IF p_hour_salary IS NULL THEN
        RAISE_APPLICATION_ERROR(-20003, 'El salario por hora es obligatorio.');
    END IF;

    SELECT COUNT(*)
    INTO v_employee_count
    FROM my_work_employees
    WHERE person_id = p_person_id;

    IF v_employee_count = 0 THEN
        RAISE_APPLICATION_ERROR(-20004, 'No existe la persona colaboradora ' || p_person_id || '.');
    END IF;

    MERGE INTO my_work_payment_detail d
    USING (
        SELECT
            p_person_id  AS person_id,
            p_time_period AS time_period
        FROM dual
    ) s
    ON (d.person_id = s.person_id AND d.time_period = s.time_period)
    WHEN NOT MATCHED THEN
        INSERT (
            person_id,
            time_period,
            worked_status,
            worked_amount,
            extra_status,
            extra_amount,
            super_extra_amount,
            donated_status,
            donated_amount,
            final_status,
            processed_at
        )
        VALUES (
            s.person_id,
            s.time_period,
            'I',
            0,
            'I',
            0,
            0,
            'I',
            0,
            'I',
            SYSDATE
        );

    SELECT
        NVL(worked_status, 'I'),
        NVL(worked_amount, 0),
        NVL(extra_status, 'I'),
        NVL(extra_amount, 0),
        NVL(super_extra_amount, 0),
        NVL(donated_status, 'I'),
        NVL(donated_amount, 0),
        NVL(final_status, 'I')
    INTO
        v_worked_status,
        v_worked_amount,
        v_extra_status,
        v_extra_amount,
        v_super_extra_amount,
        v_donated_status,
        v_donated_amount,
        v_final_status
    FROM my_work_payment_detail
    WHERE person_id = p_person_id
      AND time_period = p_time_period
    FOR UPDATE;

    IF v_final_status = 'C' THEN
        DBMS_OUTPUT.PUT_LINE(
            'La persona ' || p_person_id || ' ya tiene el pago completo en el periodo ' ||
            TO_CHAR(p_time_period, 'YYYY-MM-DD') || '.'
        );
        COMMIT;
        RETURN;
    END IF;

    IF p_hour_salary < 0 THEN
        v_worked_status      := 'I';
        v_worked_amount      := 0;
        v_extra_status       := 'I';
        v_extra_amount       := 0;
        v_super_extra_amount := 0;
        v_donated_status     := 'I';
        v_donated_amount     := 0;
        v_final_status       := 'I';
    ELSIF p_hour_salary = 0 THEN
        v_worked_status      := 'C';
        v_worked_amount      := 0;
        v_extra_status       := 'C';
        v_extra_amount       := 0;
        v_super_extra_amount := 0;
        v_donated_status     := 'C';
        v_donated_amount     := 0;
        v_final_status       := 'C';
    ELSE
        IF v_donated_status <> 'C' THEN
            IF NVL(p_donated_hours, 0) < 0 THEN
                v_donated_status := 'I';
                v_donated_amount := 0;
            ELSIF NVL(p_donated_hours, 0) = 0 THEN
                v_donated_status := 'C';
                v_donated_amount := 0;
            ELSE
                v_donated_amount := ROUND(p_hour_salary * p_donated_hours, 2);

                SAVEPOINT sp_donation;
                BEGIN
                    credit_account(c_foundation_account, v_donated_amount);
                    debit_account(c_foundation_company_account, v_donated_amount);
                    credit_account(c_foundation_account, v_donated_amount);
                    v_donated_status := 'C';
                EXCEPTION
                    WHEN OTHERS THEN
                        ROLLBACK TO sp_donation;
                        DBMS_OUTPUT.PUT_LINE(
                            'Donacion incompleta de la persona ' || p_person_id || ': ' || SQLERRM
                        );
                        v_donated_status := 'I';
                        v_donated_amount := 0;
                END;
            END IF;
        END IF;

        v_effective_donation := CASE
            WHEN v_donated_status = 'C' THEN NVL(v_donated_amount, 0)
            ELSE 0
        END;

        IF v_worked_status <> 'C' THEN
            IF NVL(p_worked_hours, 0) < 0 THEN
                v_worked_status := 'I';
                v_worked_amount := 0;
            ELSIF NVL(p_worked_hours, 0) = 0 THEN
                v_worked_status := 'C';
                v_worked_amount := 0;
            ELSE
                v_worked_amount := ROUND((p_hour_salary * p_worked_hours) - v_effective_donation, 2);

                IF v_worked_amount < 0 THEN
                    v_worked_status := 'I';
                    v_worked_amount := 0;
                ELSE
                    SAVEPOINT sp_worked;
                    BEGIN
                        debit_account(c_worked_account, v_worked_amount);
                        v_worked_status := 'C';
                    EXCEPTION
                        WHEN OTHERS THEN
                            ROLLBACK TO sp_worked;
                            DBMS_OUTPUT.PUT_LINE(
                                'Pago ordinario incompleto de la persona ' || p_person_id || ': ' || SQLERRM
                            );
                            v_worked_status := 'I';
                            v_worked_amount := 0;
                    END;
                END IF;
            END IF;
        END IF;

        IF v_extra_status <> 'C' THEN
            IF NVL(p_extra_hours, 0) < 0 OR NVL(p_super_extra_hours, 0) < 0 THEN
                v_extra_status       := 'I';
                v_extra_amount       := 0;
                v_super_extra_amount := 0;
            ELSIF NVL(p_extra_hours, 0) = 0 AND NVL(p_super_extra_hours, 0) = 0 THEN
                v_extra_status       := 'C';
                v_extra_amount       := 0;
                v_super_extra_amount := 0;
            ELSE
                v_extra_amount       := ROUND(p_hour_salary * NVL(p_extra_hours, 0) * 1.5, 2);
                v_super_extra_amount := ROUND(p_hour_salary * NVL(p_super_extra_hours, 0) * 2, 2);

                SAVEPOINT sp_extra_group;
                BEGIN
                    IF NVL(p_extra_hours, 0) > 0 THEN
                        debit_account(c_extra_account, v_extra_amount);
                    END IF;

                    IF NVL(p_super_extra_hours, 0) > 0 THEN
                        debit_account(c_extra_account, v_super_extra_amount);
                    END IF;

                    v_extra_status := 'C';
                EXCEPTION
                    WHEN OTHERS THEN
                        ROLLBACK TO sp_extra_group;
                        DBMS_OUTPUT.PUT_LINE(
                            'Pago de extras incompleto de la persona ' || p_person_id || ': ' || SQLERRM
                        );
                        v_extra_status       := 'I';
                        v_extra_amount       := 0;
                        v_super_extra_amount := 0;
                END;
            END IF;
        END IF;

        v_final_status := CASE
            WHEN v_worked_status = 'C'
             AND v_extra_status = 'C'
             AND v_donated_status = 'C'
                THEN 'C'
            ELSE 'I'
        END;
    END IF;

    UPDATE my_work_payment_detail
    SET worked_status       = v_worked_status,
        worked_amount       = NVL(v_worked_amount, 0),
        extra_status        = v_extra_status,
        extra_amount        = NVL(v_extra_amount, 0),
        super_extra_amount  = NVL(v_super_extra_amount, 0),
        donated_status      = v_donated_status,
        donated_amount      = NVL(v_donated_amount, 0),
        final_status        = v_final_status,
        processed_at        = SYSDATE
    WHERE person_id = p_person_id
      AND time_period = p_time_period;

    COMMIT;

    DBMS_OUTPUT.PUT_LINE(
        'Pago procesado -> persona: ' || p_person_id ||
        ', periodo: ' || TO_CHAR(p_time_period, 'YYYY-MM-DD') ||
        ', estado final: ' || v_final_status ||
        ', ordinario: ' || TO_CHAR(NVL(v_worked_amount, 0), 'FM999G999G990D00') ||
        ', extra: ' || TO_CHAR(NVL(v_extra_amount, 0), 'FM999G999G990D00') ||
        ', super extra: ' || TO_CHAR(NVL(v_super_extra_amount, 0), 'FM999G999G990D00') ||
        ', donacion: ' || TO_CHAR(NVL(v_donated_amount, 0), 'FM999G999G990D00')
    );
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('Error en sp_process_payroll_person_data: ' || SQLERRM);
        RAISE;
END;
/

CREATE OR REPLACE PROCEDURE sp_process_payroll_person (
    p_time_period   IN DATE,
    p_person_id     IN NUMBER
)
AS
    v_hour_salary         my_work_employees.hour_salary%TYPE;
    v_worked_hours        my_work_payment_info.worked_hours%TYPE;
    v_extra_hours         my_work_payment_info.extra_hours%TYPE;
    v_super_extra_hours   my_work_payment_info.super_extra_hours%TYPE;
    v_donated_hours       my_work_payment_info.donated_hours%TYPE;
BEGIN
    IF p_time_period IS NULL THEN
        RAISE_APPLICATION_ERROR(-20020, 'El periodo es obligatorio.');
    END IF;

    IF p_person_id IS NULL THEN
        RAISE_APPLICATION_ERROR(-20021, 'La persona es obligatoria.');
    END IF;

    SELECT
        e.hour_salary,
        pi.worked_hours,
        pi.extra_hours,
        pi.super_extra_hours,
        pi.donated_hours
    INTO
        v_hour_salary,
        v_worked_hours,
        v_extra_hours,
        v_super_extra_hours,
        v_donated_hours
    FROM my_work_employees e
    JOIN my_work_payment_info pi
        ON pi.person_id = e.person_id
    WHERE e.person_id = p_person_id
      AND pi.time_period = p_time_period;

    sp_process_payroll_person_data(
        p_time_period,
        p_person_id,
        v_hour_salary,
        v_worked_hours,
        v_extra_hours,
        v_super_extra_hours,
        v_donated_hours
    );
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(
            -20022,
            'No existe informacion de pago para la persona ' || p_person_id || ' en el periodo ' ||
            TO_CHAR(p_time_period, 'YYYY-MM-DD') || '.'
        );
END;
/

CREATE OR REPLACE PROCEDURE sp_process_payroll_period (
    p_time_period IN DATE
)
AS
    TYPE t_person_ids IS TABLE OF my_work_payment_info.person_id%TYPE;
    v_person_ids t_person_ids;
BEGIN
    IF p_time_period IS NULL THEN
        RAISE_APPLICATION_ERROR(-20030, 'El periodo es obligatorio.');
    END IF;

    SELECT person_id
    BULK COLLECT INTO v_person_ids
    FROM my_work_payment_info
    WHERE time_period = p_time_period
    ORDER BY person_id;

    IF v_person_ids.COUNT = 0 THEN
        DBMS_OUTPUT.PUT_LINE(
            'No hay personas registradas en el periodo ' || TO_CHAR(p_time_period, 'YYYY-MM-DD') || '.'
        );
        RETURN;
    END IF;

    FOR i IN 1 .. v_person_ids.COUNT LOOP
        sp_process_payroll_person(p_time_period, v_person_ids(i));
    END LOOP;
END;
/
